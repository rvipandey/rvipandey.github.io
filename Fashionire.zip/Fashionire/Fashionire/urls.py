"""Fashionire URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.views.generic import RedirectView
from  django.conf import settings
from django.conf.urls.static import static
from Modistabox.views import modistabase,modistawomen,modistamen,modistakids,login,nepage,boxselection,detailview
from django.contrib.staticfiles.urls import staticfiles_urlpatterns


urlpatterns = [
    url(r'^Modistabox/login/$', login, name="login"),
    url(r'^Modistabox/modistabase/$',modistabase,name="base"),
    url(r'^Modistabox/modistawomen/$',modistawomen, name="woman"),
    url(r'^Modistabox/modistamen/$',modistamen, name="Men"),
    url(r'^Modistabox/modistakids/$',modistakids, name="Kids"),
    url(r'^Modistabox/newpage/$', nepage, name="n"),
    url(r'^Modistabox/detailview/$', detailview, name="n"),
    url(r'^Modistabox/selection/$', boxselection, name="bx"),
    url(r'^$', RedirectView.as_view(url='Modistabox/login/'))]
urlpatterns +=staticfiles_urlpatterns()


# urlpatterns = [
#     path('admin/', admin.site.urls),
# ]
