from django.apps import AppConfig


class ModistaboxConfig(AppConfig):
    name = 'Modistabox'
