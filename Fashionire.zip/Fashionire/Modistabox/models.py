from django.db import models


# Create your models here.


def authentication(username,password):
    value=loginlookup()
    return value

def loginlookup(username,password,db):
    #query here for checking database
    value=1
    return value

