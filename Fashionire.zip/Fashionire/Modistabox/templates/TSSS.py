import requests
URL = "http://13.232.238.151:12000/ api/fitCloth"
PARAMS ={"frontImageHuman" :"https://s3.amazonaws.com/measuretalkfile/images/frontImageHuman_15464976620296552.jpg",
"clothImageUpper" : "https://s3.amazonaws.com/measuretalkfile/image3.jpg",
"clothImageLower" :"https://s3.amazonaws.com/measuretalkfile/jeans5.jpeg",
"upperClothVerticalHeight": 64,
"upperClothShoulderWidth": 50,
"lowerClothVerticalHeight": 93,
"lowerClothWaistWidth": 98,
"height":176,
"weight":73,
"gender":"male"
}
r = requests.post(url = URL, params = PARAMS)
data = r.json()

print(data)



import json
url = "http://13.232.238.151:12000/ api/fitCloth"

PARAMS ={"frontImageHuman" :"https://s3.amazonaws.com/measuretalkfile/images/frontImageHuman_15464976620296552.jpg",
"clothImageUpper" : "https://s3.amazonaws.com/measuretalkfile/image3.jpg",
"clothImageLower" :"https://s3.amazonaws.com/measuretalkfile/jeans5.jpeg",
"upperClothVerticalHeight": 64,
"upperClothShoulderWidth": 50,
"lowerClothVerticalHeight": 93,
"lowerClothWaistWidth": 98,
"height":176,
"weight":73,
"gender":"male"
}
r = requests.post(url, data=json.dumps(PARAMS))




import requests
import json
url = "http://13.232.238.151:12000/api/fitCloth"
data = {"frontImageHuman" :"https://s3.amazonaws.com/measuretalkfile/images/frontImageHuman_15464976620296552.jpg","clothImageUpper" : "https://s3.amazonaws.com/measuretalkfile/image3.jpg",
"clothImageLower" :"https://s3.amazonaws.com/measuretalkfile/jeans5.jpeg","upperClothVerticalHeight": 64,"upperClothShoulderWidth": 50,"lowerClothVerticalHeight": 93,"lowerClothWaistWidth": 98,
"height":176,"weight":73,"gender":"male"}
headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
r = requests.post(url, data=json.dumps(data), headers=headers)
print(r)