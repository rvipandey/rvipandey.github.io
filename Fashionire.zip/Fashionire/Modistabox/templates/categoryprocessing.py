import pandas as pd
datframe=pd.read_excel('C:\\Users\\rpande28\\Documents\\50k\\ATR.xlsx',sheetname='Upper')
datframe=datframe.fillna(" ")

Brands=datframe["Brand"].unique()
fabric=datframe["Fabric"].unique()
fitprefences=datframe["FitPrefrences"].unique()
Color=datframe["Color"].unique()
size=datframe["Size"].unique()
sizetype=datframe["SizeType"].unique()

# Gender	Super Category	Category	SubCategory	SubCategoryL2	SubCategoryL3	SubCategoryL4
for row in datframe.itertuples():    # print(row.Gender)
    print(row.Category)
    print(row.SubCategory)
    print(row.SubCategoryL2)
    print(row.SubCategoryL3)
    print(row.SubCategoryL4)