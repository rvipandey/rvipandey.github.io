
import pandas as pd

list=[['1','Ravi Pandey','10']]
list.append(['2','Ravix','8'])
list.append(['3','Raviy','9'])
list.append(['4','Raviz','9'])
list.append(['5','Ravia','9'])
list.append(['6','Ravib','9'])
ds=pd.DataFrame(list,columns=['Boxid','UserName',' Total Question Selected'])



print(ds)