import os
dirpath = "C:\\Users\\rpande28\\Desktop\\calls transc\\CATHRINE\\archive8\\"
wavfilelist = [name for name in os.listdir(dirpath) if name.endswith(".wav")]
for a in wavfilelist:
    os.rename(dirpath+a,dirpath+a+'.txt')
