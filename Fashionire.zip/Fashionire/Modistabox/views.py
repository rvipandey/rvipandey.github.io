import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import HttpResponse
from  django.contrib import  admin
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.files.storage import FileSystemStorage
import Modistabox.models
import subprocess
import pandas as pd
datframe=pd.read_excel('C:\\Users\\rpande28\\Documents\\50k\\ATR.xlsx',sheetname='Upper')
datframe=datframe.fillna(" ")
Brands=datframe["Brand"].unique()
fabric=datframe["Fabric"].unique()
fitprefences=datframe["FitPrefrences"].unique()
Color=datframe["Color"].unique()
Color=set(Color)
size=datframe["Size"].unique()
sizetype=datframe["SizeType"].unique()
category=datframe["Category"].unique()
subcat1=['Tops & Dresses','Bottomwear','Footwear','Accessories']
subcatt2=datframe["SubCategory"].unique()
vl=len(subcatt2)
print(vl)

# Category	SubCategory	SubCategoryL2	SubCategoryL3	SubCategoryL4
finaldataframe= pd.DataFrame({'count' : datframe.groupby( [ "SubCategory","SubCategoryL2"] ).size()}).reset_index()


finaldaaframe= pd.DataFrame({'count' : datframe.groupby( [ "SubCategory","SubCategoryL2","SubCategoryL3"] ).size()}).reset_index()


filter = finaldaaframe["SubCategoryL3"] != " "
dfNew = finaldaaframe[filter]


#finaldataframe= datframe.groupby( ["Category"]).count() #, "SubCategory","SubCategoryL2","SubCategoryL3","SubCategoryL4"] ).count()






# Category	SubCategory	SubCategoryL2	SubCategoryL3	SubCategoryL4
#

loginlist=[['Ravi Pandey','ravi_pandey@modistabox.com','xya234']]
loginlist.append(['Ashutosh Gaur','ash_gaur@modistabox.com','xya234'])
list=[['1','Ravi Pandey','10']]
list.append(['2','Ravix','8'])
list.append(['3','Raviy','9'])
list.append(['4','Raviz','9'])
list.append(['5','Ravia','9'])
list.append(['6','Ravib','9'])
list.append(['7','Ravic','3'])
list.append(['8','Ravid','5'])
list.append(['9','mqehqg','7'])
list.append(['10','madhav','7'])
list.append(['11','madhav','7'])
ds=pd.DataFrame(list,columns=['Boxid','UserName','Ts'])
dsku=pd.DataFrame(columns=['boxid','OrderId','Category','SKU','Description'])
dboxAnswer=pd.DataFrame(columns=['boxid','Questionid','Answered'])
dboxApproxprice=pd.DataFrame(columns=['boxid','ApproxPrice'])


#context["data"]= [{"id": 0, "day": "2017-01-01", "data": "100.0"}, {...}, {...}]
# mylist=['Makeup','Fashion','Cosmetics','Cosmetics','Cosmetics','Cosmetics','Cosmetics','Cosmetics','Cosmetics']


#
# @register.simple_tag
# def relative_url(value, field_name, urlencode=None):
#     url = '?{}={}'.format(field_name, value)
#     if urlencode:
#         querystring = urlencode.split('&')
#         filtered_querystring = filter(lambda p: p.split('=')[0] != field_name, querystring)
#         encoded_querystring = '&'.join(filtered_querystring)
#         url = '{}&{}'.format(url, encoded_querystring)
#     return url
#

def detailview(request):
    # if(request.Post):
    #     ""
    # else:
    #     return render(request,"Login.html",{"Exceeption": 0})
    return  render(request,'detailview.html')


def login(request):
    # if(request.Post):
    #     ""
    # else:
    #     return render(request,"Login.html",{"Exceeption": 0})
    return  render(request,'Login.html')


def boxselection(request):
    query=request.GET.get('category')
    print(query)
    return render(request,'selection.html',{'fsa':dfNew,'fulldataframe':finaldataframe,'category':category,'subcat1':subcat1,'subcat2':subcatt2,'Brandname':Brands,'Size':size,'SizeType':sizetype,'fabric':fabric,'fitprferences':fitprefences,'Color':Color})



def nepage(request):
    return render(request,'Base.html')

def modistabase(request):
    return render(request,'index.html')

def modistawomen(request):
    return render(request,'woman.html',{'array':ds,'number':7})

def modistamen(request):
    return render(request,'modistamen.html')

def modistakids(request):
    return  render(request,'kids.html')


# Create your views here.
