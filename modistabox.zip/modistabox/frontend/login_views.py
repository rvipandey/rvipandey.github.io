import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import *
from django.contrib import  admin
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.files.storage import FileSystemStorage
from django.contrib import auth
from frontend.models import UserData,about_yourself as ay,first_page as fp
from twilio.rest import Client

def country_code(user_country):
    if(to_str(user_country)==('UAE' or 'uae')):
        return +971
    elif(to_str(user_country)==('Saudi Arabia' or 'SAUDI ARABIA')):
        return +966

def opt_generate(user_country,user_mobile):
    #opt generate @zulu
    country_code=get_country_code(user_country)
    #twilio solution
    account_sid = 'ACedbcb1fa64595f91c4c23f33d7947b8f'
    auth_token = '82e465c74f8d560293473dad920117e6'
    client = Client(account_sid,auth_token)
    client.messages.create(to="+919717224144", 
                        #from_="+14847465048", 
                        #body="Hello from Python!")
    print(message.sid)
    ## to generate otp we can use pyotp
    
def verify_opt():{}

def facebook_login():{}

def google_login():{}

def mobile_login():{}   