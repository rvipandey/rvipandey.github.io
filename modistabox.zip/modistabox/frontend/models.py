from django.db import models

# Create your models here.
class UserData(models.Model):
    #userid = models.CharField(max_length=10, primary_key=True)
    user_mobile = models.CharField(max_length=10)
    user_country=models.CharField(max_length=90)
    user_email=models.CharField(max_length=50)
    user_social=models.CharField(max_length=50)

class first_page(models.Model):
    #userid = models.CharField(max_length=10, primary_key=True)
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    looking_style = models.CharField(max_length=10)
    birthday=models.CharField(max_length=90)
    occasion=models.CharField(max_length=50)
    last_session_time=models.CharField(max_length=50)
    #user_social=models.CharField(max_length=50)


class about_yourself(models.Model):
    #userid = models.CharField(max_length=10, primary_key=True)
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    body_shape = models.CharField(max_length=10)
    height=models.CharField(max_length=10)
    height_cm=models.CharField(max_length=10)
    weight=models.CharField(max_length=10)
    weight_cm=models.CharField(max_length=10)
    profession=models.CharField(max_length=50)
    differentlooks=models.CharField(max_length=50)
    wardrob_items=models.CharField(max_length=50)
    outfit_likes=models.CharField(max_length=50)
    color_likes=models.CharField(max_length=50)
    clothing_materials=models.CharField(max_length=50)
    skin_tone=models.CharField(max_length=50)
    hair_color=models.CharField(max_length=50)
    wardrob_brands=models.CharField(max_length=50)
    travelling_time=models.CharField(max_length=50)
    fabric=models.CharField(max_length=50)

class tops_dresses(models.Model):
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    top_size_wear=models.CharField(max_length=10)
    bra_size=models.CharField(max_length=10)
    cup_size=models.CharField(max_length=10)
    upper_body_top_type=models.CharField(max_length=100)
    arms=models.CharField(max_length=10)
    shoulder=models.CharField(max_length=10)
    upper_back=models.CharField(max_length=10)
    cleavage=models.CharField(max_length=10)
    stomach=models.CharField(max_length=10)
    abaya=models.CharField(max_length=10)
    abaya_size=models.CharField(max_length=50)
    add_abaya_wardrobe=models.CharField(max_length=50)
    hijab=models.CharField(max_length=50)
    #hiow often you buy these things 
    tops=models.CharField(max_length=50)
    blazzer=models.CharField(max_length=50)
    jackets=models.CharField(max_length=50)
    coat=models.CharField(max_length=50)
    shirts=models.CharField(max_length=50)
    hoodies_sweatshirt=models.CharField(max_length=50)
    t_shirt=models.CharField(max_length=50)
    dresses=models.CharField(max_length=50)
    abaya_fequency=models.CharField(max_length=50)
    hijab_freq=models.CharField(max_length=50)
    #Which of these would you want more in your wardrobe?

    
class bottom(models.Model):
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    add_2wardrobe=models.CharField(max_length=100)
    #waist size?
    waist_size=models.CharField(max_length=50)
    #which of these do you prefer ?
    lower_cloth_options=models.CharField(max_length=100)
    #what kind of style do you prefer on lower body ?
    lower_body_fit=models.CharField(max_length=50)
    #how often you but these things ?
    jeans=models.CharField(max_length=50)
    pants=models.CharField(max_length=50)
    skirts=models.CharField(max_length=50)
    shorts=models.CharField(max_length=50)
    sweatpnats=models.CharField(max_length=50)
    leggings=models.CharField(max_length=50)
    #what types of jeans/pants you prefer ?
    fit_wise=models.CharField(max_length=50)
    rise_wise=models.CharField(max_length=50)
    style_wise=models.CharField(max_length=50)
    faint_styte=models.CharField(max_length=50)
    color_theme=models.CharField(max_length=50)
    distressed_stle=models.CharField(max_length=50)
    #which of these would you want more in your wardrobe ?
    want_more_wardrobe=models.CharField(max_length=50)
    

class shoe_accessories(models.Model):
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    shoe_size=models.CharField(max_length=50)
    toe_type=models.CharField(max_length=50)
    shoe_shape_prefrence=models.CharField(max_length=50)
    style_footwear_prefer=models.CharField(max_length=50)
    jwellery_prefer=models.CharField(max_length=50)
    #Are your ear pierced?
    ear_pierced=models.CharField(max_length=50)
    #how often you buty these things ?
    buy_trend_ass=models.CharField(max_length=50)
    #what vategory you want more in your wardrobe ?
    add_ass_2wardobe=models.CharField(max_length=50)



class budget_pricing(models.Model):
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    #budgets for tops 
    budget_normal_range_tops=models.CharField(max_length=50)
    budget_special_range_tops=models.CharField(max_length=50)
    #budget for dresses
    budget_normal_range_dresses=models.CharField(max_length=50)
    budget_special_range_dresses=models.CharField(max_length=50)
    #budget for abaya and hijab ?
    budget_normal_range_abaya_hijab=models.CharField(max_length=50)
    budget_special_range_abaya_hijab=models.CharField(max_length=50)
    #budget for jeans and pants ?
    budget_normal_range_jeans_pants=models.CharField(max_length=50)
    budget_special_range_jeans_pants=models.CharField(max_length=50)
    #budget for skirts ?
    budget_normal_range_skirt=models.CharField(max_length=50)
    budget_special_range_skirt=models.CharField(max_length=50)
    #budget for watches ?
    budget_normal_range_watches=models.CharField(max_length=50)
    budget_special_range_watches=models.CharField(max_length=50)
    #budgets for sunglasses ?
    budget_normal_range_sunglasses=models.CharField(max_length=50)
    budget_special_range_sunglases=models.CharField(max_length=50)
    #budget for jwellery ?
    budget_normal_range_jwellery=models.CharField(max_length=50)
    budget_special_range_jwellery=models.CharField(max_length=50)    

class checkout(models.Model):
    styleid=models.CharField(max_length=100)
    items=models.CharField(max_length=50)
    price=models.CharField(max_length=50)
    total=models.CharField(max_length=50)
    grandtotal=models.CharField(max_length=50)
    
class otp_db(models.Model):
    session=models.CharField(max_length=50)
    styleid=models.CharField(max_length=100)
    otp_id=models.IntegerField(max_length=6)
    otp_number=models.IntegerField(max_length=20)
    opt_place=models.CharField(max_length=10)


    



