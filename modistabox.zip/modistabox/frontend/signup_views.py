import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import *
from django.contrib import  admin
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.files.storage import FileSystemStorage
from django.contrib import auth
from frontend.models import UserData,about_yourself as ay,first_page as fp
from twilio.rest import Client

def verify_signup_db():{}

def store_user_info():{}

def facebook_signup():{}

def mobile_signup():{}

def google_signup():{}