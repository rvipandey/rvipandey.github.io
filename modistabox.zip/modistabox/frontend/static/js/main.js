function PrintElem(e) {
    Popup(jQuery(e).html())
}

function Popup(e) {
    var r = window.open("", "my div");
    r.document.write("<html><head><title>SNOBBOX INVOICE</title>"), r.document.write(e), r.document.write("</body></html>"), r.document.close(), r.print()
}

function online_payment() {}

function validate(e) {
    var r = e || window.event,
    t = r.keyCode || r.which;
    t = String.fromCharCode(t);
    var a = /[0-9]/;
    a.test(t) || (r.returnValue = !1, r.preventDefault && r.preventDefault())
}


$(function() {
    /*$("#continueCheckout")on('click', function() {
    $('#checkoutModal').modal('show');
});*/
$("#continueCheckout").on('click', function() {
    //console.log(checkoutReviewValidate());return false;
    if(checkoutReviewValidate()) {
        //alert('asddf');
        $('#checkoutModal').modal({
            backdrop: 'static',
            keyboard: false
        });
    }
    /*else {
    alert('65');
}*/
});
});

function submitCheckoutReviewValidate() {
    var agreeCheckout = $("input[name='agreeCheckout']:checked").val();
    var flag = 0;
    //alert(agreeCheckout);return false;

    /*if(agreeCheckout == '' || agreeCheckout == null) {
    $('#snobboxAgreeError').html('You must agree the terms and condition before confirming.');
    flag++;
}
else {
$('#snobboxAgreeError').html('');
}*/
//return false;
if(flag > 0) {
    return false;
}
else {
    return true;
}
}

function checkoutReviewValidate() {

    //var agreeCheckout = $("input[name='agreeCheckout']:checked").val();
    //alert(agreeCheckout);return false;

    var snobboxRating = $('#snobboxRating').val();
    var snobboxFrequency = $("input[name='snobboxFrequency']:checked").val();
    var flag = 0;

    /*if(agreeCheckout == '' || agreeCheckout == null) {
    $('#snobboxAgreeError').html('You must agree the terms and condition before confirming.');
    flag++;
}
else {
$('#snobboxAgreeError').html('');
}*/

if(snobboxRating == '' || snobboxRating == null || snobboxRating == 0 || snobboxRating == '0') {
    $('#ratingError').html('Please give rating.');
    flag++;
}
else {
    $('#ratingError').html('');
}

if(snobboxFrequency == '' || snobboxFrequency == null) {
    $('#snobboxFrequencyError').html('Please select frequency.');
    flag++;
}
else {
    $('#snobboxFrequencyError').html('');
}
//alert(flag);
//return false;
if(flag > 0) {
    return false;
}
else {
    return true;
}

}


/*function checkoutReviewValidate() {
var e = $("#snobboxRating").val(),
r = $("input[name='snobboxFrequency']:checked").val(),
t = 0;
return "" == e || null == e || 0 == e || "0" == e ? ($("#ratingError").html("Please give rating."), t++) : $("#ratingError").html(""), "" == r || null == r ? ($("#snobboxFrequencyError").html("Please select frequency."), t++) : $("#snobboxFrequencyError").html(""), t > 0 ? !1 : !0
}*/

function set_radio_occ(e) {
    $("input#" + e).click(), $("#occ_" + e).addClass("occ_active"), 1 == $("#" + e).prop("checked") ? $("#occ_" + e).addClass("occ_active") : $("#occ_" + e).removeClass("occ_active")
}

function noBack() {
    window.history.forward()
}

function login_submit(e) {
    if ("13" == e.which || "click" == e.type) {
        $("#login_error").html("");
        var r = $("#login_email").val(),
        t = $("#login_password").val(),
        a = 0,
        o = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
        if (o.test(r) && "" != r && null != r ? $("#err_login_email").removeClass("lb_error") : (a++, $("#err_login_email").addClass("lb_error")), "" == t || null == t ? (a++, $("#err_login_password").addClass("lb_error")) : $("#err_login_password").removeClass("lb_error"), a > 0) return !1;
        var n = {
            login_email: r,
            login_password: t,
            ajax: 2
        };
        $.ajax({
            type: "POST",
            url: host_url + "/login",
            data: n,
            beforeSend: function(e) {
                $("#login_submit").attr("disabled", !0), $("#login_submit").val("Please wait..."), $(".form-group").attr("disabled", !0)
            },
            success: function(e) {
                try {
                    if("login succesfully" == e.status)
                    {
                        // console.log(r);
                        smartech('create', 'ADGMOT35CHFLVDHBJNIG50K969PN1PHHN46QFUB131KQTEL0JM8G');
                        smartech('register', '92efc4771106fae1f50305687fddc55d');
                        smartech('identify', r); /* Please pass EMAIL if available , else blank */
                        smartech('dispatch',1,{});
                    }
                } catch (e) {
                    console.log(e);
                } finally {
                    "login succesfully" == e.status ? $(location).attr("href", "schedule") : ($("#login_error").html(""), $("#login_submit").attr("disabled", !1), $("#login_submit").val("SIGN IN"), $(".form-group").attr("disabled", !1), $("#login_error").html("Invalid Credentials"))
                }
            }
        })
    }
}

function schedule_snobbox() {
    var e = "Normal";
    $("#bType").attr("rel");
    var r = $("#datepicker_value").val(),
    t = $("#payLaterCheck_pincode").val(),
    a = $("#pl_pincodeCheck_flag").val();
    var city_id = $("#select_city").val();

    if ($("#auto_ship").is(":checked")) {
        var o = $("input[type='radio']:checked").val();
        if ("" == o || null == o) return $("#schedule_error_msg").html("<br>Please select frequency."), !1;
        var n = new Date(r),
        s = new Date(n.getTime() + 24 * o * 60 * 60 * 1e3),
        l = s,
        i = s.getDate(),
        c = s.getMonth() + 1,
        d = s.getFullYear(),
        l = (s.getDay(), c + "/" + i + "/" + d),
        p = o
    } else l = "", p = "";
    if ("" == e || null == e) return $("#schedule_error_msg").html("<br>Please select blogger."), !1;
    if ("" == r || null == r) return $("#schedule_error_msg").html("<br>Please select date."), !1;
    $("#schedule_error_msg").html("");
    var u = {
        bType: e,
        datepicker_value: r,
        finalpincode: t,
        pay_later_flag: a,
        nextscheduledate: l,
        schedule_frequency: p,
        city_id:city_id,
    };
    $.ajax({
        type: "POST",
        url: host_url + "/scheduledetail",
        data: u,
        success: function(e) {
            (e.status = "success") ? $(location).attr("href", "notepage"): $("#schedule_error_msg").html("Error occured. Please try after sometime.")
        }
    })
}

function blogger_schedule_snobbox() {
    var e = $("#bType").attr("rel"),
    r = $("#payLaterCheck_pincode").val(),
    t = ($("#pl_pincodeCheck_flag").val(), $("input:radio[name=blogger_schedule_date]:checked").val()),
    a = $("input:radio[name=blogger_schedule_date]:checked").attr("rel");
    if ("" == e || null == e) return $("#schedule_error_msg").html("<br>Please select blogger."), !1;
    if ("" == t || null == t) return $("#schedule_error_msg").html("<br>Please select date and time."), !1;
    if (e.toLowerCase() != a.toLowerCase()) return $("#schedule_error_msg").html("<br>Please select date and time."), !1;
    $("#schedule_error_msg").html("");
    var o = {
        bType: e,
        finalpincode: r,
        pay_later_flag: 1,
        datepicker_value: t
    };
    $.ajax({
        type: "POST",
        url: host_url + "/scheduledetail",
        data: o,
        success: function(e) {
            (e.status = "success") ? $(location).attr("href", "shippingaddress"): $("#schedule_error_msg").html("Error occured. Please try after sometime.")
        }
    })
}

function bloggerCardsOrientation(e) {
    console.log(e.orientation)
}

function bloggerOrientation() {
    var e = screen.orientation || screen.mozOrientation || screen.msOrientation;
    console.log(e.type), "landscape-primary" == e.type ? ($(".bloggerCard").removeClass("col-lg-4 col-lg-offset-0 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-0 col-xs-8 col-xs-offset-0"), $(".bloggerCard").addClass("col-md-4 col-sm-4 col-xs-4")) : "landscape-secondary" == e.type ? ($(".bloggerCard").removeClass("col-lg-4 col-lg-offset-0 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-0 col-xs-8 col-xs-offset-0"), $(".bloggerCard").addClass("col-md-4 col-sm-4 col-xs-4")) : ("portrait-secondary" == e.type || "portrait-primary" == e.type) && ($(".bloggerCard").removeClass("col-md-4 col-sm-4 col-xs-4"), $(".bloggerCard").addClass("col-lg-4 col-lg-offset-0 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-0 col-xs-8 col-xs-offset-0"))
}
var host_url = location.protocol + "//" + location.host;
$(window).on("load", function(e) {
    bloggerOrientation()
}), $(window).on("orientationchange", function(e) {
    bloggerOrientation()
}), $(document).ready(function() {
    $(window).scroll(function() {
        $(window).scrollTop() > 10 ? $(".del_hdgoffer").css("display", "none") : $(".del_hdgoffer").css("display", "block")
    })
}), $(document).ready(function() {
    $(".userbudget").on("click", function() {
        var e = $(this).attr("id");
        $("#selectedbudget").html(e), $(".selecteonlinedbudget").html(e)
    }), $("#check-data, #skip-n-check-data").on("click", function() {
        $(this).attr("disabled", !0), $(this).val("Please wait..."), $.ajax({
            type: "POST",
            url: host_url + "/completeStyleQuiz",
            data: null,
            success: function(e) {
                try {
                    smartech('dispatch', 110, {"i^Style_Quiz_Step": "12"});
                } catch (e) {
                    console.log(e);
                } finally {

                    1 == e ? window.location = host_url + "/schedule" : 0 == e && ($(this).attr("disabled", !1), $(this).val("Please wait..."), $("#nxt11").html("Upload and Save"))
                }

            },
            error: function() {}
        })
    }), $(".fb-signup").on("click", function() {
        FB.login(function(e) {
            e.authResponse ? (console.log("Welcome!  Fetching your information.... "), access_token = e.authResponse.accessToken, user_id = e.authResponse.userID, FB.api("/me?fields=name,first_name,last_name,gender,email", function(e) {
                user_email = e.email, first_name = e.first_name, last_name = e.last_name, gender = e.gender, console.log(gender), $("html, body").scrollTop($("#sign-up").offset().top), $("#source").val("facebook"), $("#user_email").val(user_email), $("#user_confirm_email").val(user_email), $("#user_first_name").val(first_name), $("#user_last_name").val(last_name), "male" == gender && $('#user_gender[value="male"]').prop("checked", !0), "female" == gender && $('#user_gender[value="female"]').prop("checked", !0)
            })) : console.log("User cancelled login or did not fully authorize.")
        }, {
            scope: "public_profile,email"
        })
    }), $(".fb-login").on("click", function() {
        FB.login(function(e) {
            e.authResponse ? (console.log("Welcome!  Fetching your information.... "), access_token = e.authResponse.accessToken, user_id = e.authResponse.userID, FB.api("/me?fields=name,first_name,last_name,gender,email", function(e) {
                user_email = e.email, first_name = e.first_name, last_name = e.last_name, gender = e.gender, console.log(gender);
                var r = {
                    email: user_email,
                    firstname: first_name,
                    lastname: last_name,
                    source: "facebook"
                };
                $.ajax({
                    async: !1,
                    type: "POST",
                    url: host_url + "social_login",
                    data: r,
                    beforeSend: function(e) {
                        $("#login_submit").attr("disabled", !0), $("#login_submit").val("Please wait..."), $(".form-group").attr("disabled", !0)
                    },
                    success: function(e) {

                        try {
                            if("login failed" != e.status)
                            {
                                smartech('create', 'ADGMOT35CHFLVDHBJNIG50K969PN1PHHN46QFUB131KQTEL0JM8G');
                                smartech('register', '92efc4771106fae1f50305687fddc55d');
                                smartech('identify',user_email); /* Please pass EMAIL if available , else blank */
                                smartech('dispatch',1,{});
                            }

                        } catch (ex) {
                            console.log(ex);
                        } finally {
                            "login failed" == e.status ? $(location).attr("href", "login") : $(location).attr("href", "stylequiz/step1")
                        }
                    }
                })
            })) : console.log("User cancelled login or did not fully authorize.")
        }, {
            scope: "public_profile,email"
        })
    }), $(".js-google-signup").on("click", function(e) {
        $("#source").val("google");
        var r = {
            clientid: "33176005200-69bedidem528f6t7u3ajhdjnse4i89c5.apps.googleusercontent.com",
            cookiepolicy: "single_host_origin",
            callback: "mySignupCallback",
            scope: "https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email",
            requestvisibleactions: "http://schemas.google.com/AddActivity"
        };
        gapi.auth.signIn(r)
    }), $(".js-google-signin").on("click", function(e) {
        var r = {
            clientid: "33176005200-69bedidem528f6t7u3ajhdjnse4i89c5.apps.googleusercontent.com",
            cookiepolicy: "single_host_origin",
            callback: "mySignInCallback",
            scope: "https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email",
            requestvisibleactions: "http://schemas.google.com/AddActivity"
        };
        gapi.auth.signIn(r)
    }), $("#user_shipping_postcode").keyup(function() {
        var e = $(this).val();
        if (6 == e.toString().length && $.isNumeric(e)) {
            var r = {
                pincode: e
            };
            $.ajax({
                type: "POST",
                url: host_url + "/pincode",
                data: r,
                success: function(e) {
                    console.log(e), 1 == e.error ? $("#pincode_result_error").html("") : ($("#pincode_result_error").html(""), $("#user_shipping_country").val(e.country), $("#user_shipping_state").val(e.state), $("#user_shipping_city").val(e.city));
                    if(e.service_status==1) {
                        $("#pincode_result_success").html('Service Available.');
                    }
                    else {
                        $("#pincode_result_error").html('Currently service not available at your pincode.');
                    }
                }
            })
        } else $("#pincode_result_success").html(""), $("#pincode_result_error").html("Invalid Pincode."), $("#user_shipping_country").val(""), $("#user_shipping_state").val(""), $("#user_shipping_city").val("")
    }), $("#letsStarted_next").click(function() {
        var e = $("#user_first_name").val(),
        fn = $("#user_first_name").val(),
        r = $("#user_last_name").val(),
        mn = $("#user_mobile").val(),
        t = $("#user_email").val(),
        d = 0,
        p = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i,
        u = /^[0-9]*$/;

        // alert(refered_by);return false;
        if ( "" == e || null == e ? (d++, $("#user_first_name").addClass("lb_error")) : $("#user_first_name").removeClass("lb_error"), "" == r || null == r ? (d++, $("#user_last_name").addClass("lb_error")) : $("#user_last_name").removeClass("lb_error"), p.test(t) && "" != t && null != t ? $("#user_email").removeClass("lb_error") : (d++, $("#user_email").addClass("lb_error")), u.test(mn) && "" != mn && null != mn ? $("#user_mobile").removeClass("lb_error") : (d++, $("#user_mobile").addClass("lb_error")), d > 0) return !1;
        var h = {
            mobile: mn
        };
        $.ajax({
            type: "POST",
            url: host_url + "/checkmobilenumber",         //checking mobile number
            data: h,
            success: function(a) {
                if (0 == a.error) {
                    var d = {
                        user_first_name: e,
                        user_last_name: r,
                        user_mobile: mn,
                        user_email:t,
                        ajax: 2
                    };
                    $.ajax({
                        type: "POST",
                        url: host_url + "/register_user",
                        data: d,
                        beforeSend: function(e) {
                            $(".letsStarted_next").attr("disabled", !0), $("#letsStarted_next").val("Please wait..."), $(".form-group").attr("disabled", !0)
                        },
                        success: function(e) {
                            try {
                                if(e.status = "User Registration Succesfully")
                                {

                                }
                            }catch(err) {
                                console.log(err);
                            }
                            finally {
                                (e.status = "User Registration Succesfully") ? $(location).attr("href", "stylequiz/step1"): $("#reg_error").html("Something went wrong. Please try after sometime...")
                            }
                        }
                    })
                } else $("#reg_error").html("Email Id already registered")
            }
        })
    }), $("#inter_15_lbl").on("click", function() {
        $(".frequency-text").html("You will receive Modistabox every 15 days")
    }), $("#inter_30_lbl").on("click", function() {
        $(".frequency-text").html("You will receive Modistabox every 30 days")
    }), $("#inter_60_lbl").on("click", function() {
        $(".frequency-text").html("You will receive Modistabox every 60 days")
    }), $("#inter_90_lbl").on("click", function() {
        $(".frequency-text").html("You will receive Modistabox every 90 days")
    }), $(".call-lbl").on("click", function() {
        lbl_id = $(this).attr("id"), inp_id = lbl_id.replace("_call", ""), $(".call-lbl").removeClass("active"), $(this).addClass("active")
    }), $(document).on("click", "#login_submit", login_submit).on("keypress", this, login_submit), $("#confirm_snobbox").on("click", function() {
        $("#confirm_snobbox").attr("disabled", !0), $("#confirm_snobbox").val("Please wait...");
        var e = $("input:radio[name=lookingFor]:checked").val();
        if (1 == $("#bloggerFlag").attr("rel")) var r = 1;
        else var r = $("input:radio[name=scheduledata]:checked").val();
        var t = $("input:checkbox[name=occasion]:checked").map(function() {
            return this.value
        }).get(),
        a = t.join(",");
        if ("" == e || null == e || "" == a || null == a || "" == r || null == r) return $("#note_error_msg").html("<br>All fields are mandatory"), $("#snobbox_note").parent().addClass("has-error"), $("#confirm_snobbox").attr("disabled", !1), $("#confirm_snobbox").val("Next To Address"), !1;
        $("#snobbox_note").parent().removeClass("has-error"), $("#note_error_msg").html("");
        var o = {
            lookingFor: e,
            occasion: a,
            stylist_call_time: r
        };
        $.ajax({
            type: "POST",
            url: host_url + "/notesuccess",
            data: o,
            success: function(e) {
                e ? ($(location).attr("href", "shippingaddress"), $("#confirm_snobbox").attr("disabled", !1), $("#confirm_snobbox").val("Next To Address")) : $("#snobbox_div").html("Some error occured")
            }
        })
    }), $("#method_cod").on("click", function() {
        $(".online-note").removeClass("bold"), $(".online-main-note").css("display", "none"), $(".cod-note").addClass("bold"), $(".cod-main-note").css("display", "block"), $("#cod_note").html("*Extra Rs. 100 for Cash on Delivery.")
    }), $("#method_online").on("click", function() {
        $(".cod-note").removeClass("bold"), $(".cod-main-note").css("display", "none"), $(".online-note").addClass("bold"), $(".online-main-note").css("display", "block"), $("#cod_note").html("")
    }), $("#couponcode").on("click", function() {
        var e = $("#couponcodenew").val();
        if ("" == e) $("#coupon_error_msg").html("Invalid coupon applied.");
        else {
            $("#coupon_msg").html(""), $("#coupon_error_msg").html("");
            var r = {
                couponcode: e
            };
            $.ajax({
                type: "POST",
                url: host_url + "/checkcoupon",
                data: r,
                success: function(e) {
                    0 == e.error ? (console.log(e.coupon), "undefined" != typeof e.coupon && null !== e.coupon && location.reload()) : ($("#coupon_error_msg").html("Invalid coupon applied."), $("#stylingFee_completeOrder").val("Pay Styling Fee Rs. 199"))
                }
            })
        }
    }), $("#couponcode_remove").on("click", function() {
        $.ajax({
            type: "POST",
            url: host_url + "/coupon_remove",
            data: null,
            success: function(e) {
                location.reload()
            }
        })
    }), $("#cancel_snobbox").unbind().click(function() {
        var e = 0,
        r = $("#user_cancle_reason").val();
        if ("Please Select" == r ? (e++, $("#err_cancle_box").addClass("lb_error")) : $("#err_cancle_box").removeClass("lb_error"), e > 0) return !1;
        var t = {
            cancle_reason: r
        };
        $.ajax({
            type: "POST",
            url: host_url + "/cancelRequest",
            data: t,
            beforeSend: function() {
                $("#cancel_snobbox").val("Please wait...")
            },
            success: function(e) {
                0 == e.error ? $(location).attr("href", "cancelnote") : 1 == e ? $(location).attr("href", "cancelRequest") : $(location).attr("href", "cancelRequest")
            }
        })
    }), $("#complete_snobbox").on("click", function() {
        $("#complete_snobbox").attr("disabled", !0), $("#complete_snobbox").val("Please wait...");
        var e = $("input:radio[name=budget]:checked").val(),
        r = $("#snobbox_note").val(),
        t = "payonline",
        a = $.trim($("#couponcodenew").val());
        if (a = a.length > 0 ? $.trim($("#couponcodenew").val()) : "", "" == e || null == e || "" == t || null == t || "" == r || null == r) return $("#payment_error_msg").html("<br>Please select budget and payment option and write comment for your snobbox."), $("#complete_snobbox").attr("disabled", !1), $("#complete_snobbox").val("Complete Your SnobBox"), !1;
        $("#payment_error_msg").html("");
        var o = {
            budget: e,
            payment_method: t,
            snobbox_note: r,
            coupon_applied: a
        };
        $.ajax({
            type: "POST",
            url: host_url + "/savepayment",
            data: o,
            success: function(e) {
                0 == e.error ? (window.history.forward(), $(location).attr("href", "orderschedule")) : ($("#complete_snobbox").attr("disabled", !1), $("#complete_snobbox").val("Complete Your SnobBox"), $("#snobbox_div").html("Some error occured"))
            }
        })
    }), $("#complete_paylater_snobbox").unbind().click(function() {
        $("#complete_paylater_snobbox").attr("disabled", !0), $("#complete_paylater_snobbox").val("Please wait...");
        var e = $("#snobbox_note").val(),
        r = "payonline",
        t = $.trim($("#couponcodenew").val());
        t = t.length > 0 ? $.trim($("#couponcodenew").val()) : "";
        var a = $.trim(e);
        if ("" == r || null == r || "" == a || null == a) return $("#payment_error_msg").html("<br>Please select payment option and write comment for your snobbox."), $("#complete_paylater_snobbox").attr("disabled", !1), $("#complete_paylater_snobbox").val("Complete Your SnobBox"), !1;
        $("#payment_error_msg").html("");
        var o = {
            payment_method: r,
            snobbox_note: a,
            coupon_applied: t
        };
        $.ajax({
            type: "POST",
            url: host_url + "/savepaylaterpayment",
            data: o,
            success: function(e) {
                0 == e.error ? (window.history.forward(), $(location).attr("href", "paylater_payment")) : ($(location).attr("href", "schedule"), $("#snobbox_div").html("Some error occured"))
            }
        })
    }), $("#stylingFee_completeOrder").unbind().click(function() {
        var e = $("input[name='budget']:checked").val();
        var payGateway = 'paytm';
        $this = $(this).attr('id');
        //alert($this);return false;
        //payGateway = $this.substring($this.lastIndexOf("_")).replace("_","");
        payGateway = $('input[name=paymentGatewayMethod]:checked').val();
        //alert(payGateway);return false
        var stylingBudget = $("input[name='stylingBudget']:checked").val();
        //alert(stylingBudget);return false;
        var final_sf = $('#sf').val();
        //alert(final_sf);return false;
        var use_storeCredit = 'no', use_ref = 'no', creditUsed = '';
        if($("input[name='useStoreCredit']").is(":checked")){
            use_storeCredit = $("input[name='useStoreCredit']:checked").val();
            creditUsed = 'sc';
        }
        if($("input[name='usecurrentRefCredit']").is(":checked")){
            use_ref = $("input[name='usecurrentRefCredit']:checked").val();
            creditUsed = 'rc';
        }
        //alert(creditUsed);return false;

        if ("undefined" == typeof e) var e = "";
        var r = $("input[name='useStoreCredit']:checked").val();
        $("#stylingFee_completeOrder").attr("disabled", !0), $("#stylingFee_completeOrder").val("Please wait...");
        var t = "payonline",
        a = $("#sf").val(),
        o = $.trim($("#couponcodenew").val());
        if (o = o.length > 0 ? $.trim($("#couponcodenew").val()) : "", "" == t || null == t) return $("#payment_error_msg").html("<br>Please select payment option for your snobbox."), $("#stylingFee_completeOrder").attr("disabled", !1), $("#stylingFee_completeOrder").val("Complete Your SnobBox"), !1;
        $("#payment_error_msg").html("");
        var n = {
            budget: e,
            payment_method: t,
            coupon_applied: o,
            sf_payable_amt: a,
            use_storeCredit: use_storeCredit,
            stylingBudget : stylingBudget,
            final_sf:final_sf,
            use_ref:use_ref,
            creditUsed:creditUsed,
            payGateway:payGateway
        };
        //console.log(n);return false;
        $.ajax({
            type: "POST",
            url: host_url + "/completeSnobboxOrder",
            data: n,
            dataType: "json",
            /*success: function(e) {
            0 == e.error ? (window.history.forward(), 1 == e.payment_flag ? $("#ccavenue").html(e.ccavenue) : $(location).attr("href", "paylater_payment")) : ($(location).attr("href", "schedule"), $("#snobbox_div").html("Some error occured"))
        }*/
        success: function(result) {
            //alert('resultasdfas');
            //$('body').html(result);
            //$('#ccavenue').html(result);
            //console.log(result);return false;
            if (result.error == false) {
                window.history.forward();
                function noBack() { window.history.forward(); }

                //$("#complete_snobbox").attr("disabled", false);
                //$('#complete_snobbox').val('Complete Your SnobBox');
                if(result.payment_flag == 1) {
                    $('#ccavenue').html(result.url);
                    $('#ccavenue').html(result.ccavenue);
                }
                else {
                    $(location).attr('href', 'paylater_payment');
                }
            } else {
                $(location).attr('href', 'schedule');
                $('#snobbox_div').html('Some error occured');
            }
        }
    })
}), $("#address_submit").on("click", function() {
    var e = $("#span_customer_id").attr("rel"),
    r = $("#shipping_first_name").val(),
    t = $("#shipping_last_name").val(),
    a = $("#shipping_address_1").val(),
    o = $("#shipping_address_2").val(),
    n = $("#shipping_mobile").val(),
    s = $("#shipping_landline").val(),
    l = $("#user_shipping_city").val(),
    i = $("#user_shipping_state").val(),
    c = $("#user_shipping_postcode").val(),
    d = 0;
    if ("" == r || null == r ? (d++, $("#shipping_first_name").parent().addClass("has-error")) : $("#shipping_first_name").parent().removeClass("has-error"), "" == t || null == t ? (d++, $("#shipping_last_name").parent().addClass("has-error")) : $("#shipping_last_name").parent().removeClass("has-error"), "" == a || null == a ? (d++, $("#shipping_address_1").parent().addClass("has-error")) : $("#shipping_address_1").parent().removeClass("has-error"), "" == o || null == o ? (d++, $("#shipping_address_2").parent().addClass("has-error")) : $("#shipping_address_2").parent().removeClass("has-error"), "" == n || null == n || 10 != n.length ? (d++, $("#shipping_mobile").parent().addClass("has-error")) : $("#shipping_mobile").parent().removeClass("has-error"), "" == l || null == l ? (d++, $("#user_shipping_city").parent().addClass("has-error")) : $("#user_shipping_city").parent().removeClass("has-error"), "" == i || null == i ? (d++, $("#user_shipping_state").parent().addClass("has-error")) : $("#user_shipping_state").parent().removeClass("has-error"), isNaN(c) || "" == c || null == c || 6 != c.length ? (d++, $("#user_shipping_postcode").parent().addClass("has-error")) : $("#user_shipping_postcode").parent().removeClass("has-error"), d > 0) return !1;
    var p = {
        customer_id: e,
        shipping_first_name: r,
        shipping_last_name: t,
        shipping_address_1: a,
        shipping_address_2: o,
        shipping_mobile: n,
        shipping_landline: s,
        shipping_city: l,
        shipping_state: i,
        shipping_pincode: c
    };
    $.ajax({
        type: "POST",
        url: host_url + "/shippinginfo",
        data: p,
        beforeSend: function(e) {
            $("#address_submit").html("Please Wait...")
        },
        success: function(e) {
            // "no" == e.paylater ? $(location).attr("href", "payment") : "yes" == e.paylater ? $(location).attr("href", "payment") : $("#shipping_address_error_msg").html("Error occured in shipping address")
            "no" == e.paylater ? $(location).attr("href", "thank-you") : "yes" == e.paylater ? $(location).attr("href", "thank-you") : $("#shipping_address_error_msg").html("Error occured in shipping address")
        }
    })
}), $("#edit_address_submit").on("click", function() {
    var e = $("#span_customer_id").attr("rel"),
    r = $("#shipping_first_name").val(),
    t = $("#shipping_last_name").val(),
    a = $("#shipping_address_1").val(),
    o = $("#shipping_address_2").val(),
    n = $("#shipping_mobile").val(),
    s = $("#shipping_landline").val(),
    l = $("#user_shipping_city").val(),
    i = $("#user_shipping_state").val(),
    c = $("#user_shipping_postcode").val(),
    d = 0;
    if ("" == r || null == r ? (d++, $("#shipping_first_name").parent().addClass("has-error")) : $("#shipping_first_name").parent().removeClass("has-error"), "" == t || null == t ? (d++, $("#shipping_last_name").parent().addClass("has-error")) : $("#shipping_last_name").parent().removeClass("has-error"), "" == a || null == a ? (d++, $("#shipping_address_1").parent().addClass("has-error")) : $("#shipping_address_1").parent().removeClass("has-error"), "" == o || null == o ? (d++, $("#shipping_address_2").parent().addClass("has-error")) : $("#shipping_address_2").parent().removeClass("has-error"), "" == n || null == n || 10 != n.length ? (d++, $("#shipping_mobile").parent().addClass("has-error")) : $("#shipping_mobile").parent().removeClass("has-error"), "" == l || null == l ? (d++, $("#user_shipping_city").parent().addClass("has-error")) : $("#user_shipping_city").parent().removeClass("has-error"), "" == i || null == i ? (d++, $("#user_shipping_state").parent().addClass("has-error")) : $("#user_shipping_state").parent().removeClass("has-error"), isNaN(c) || "" == c || null == c || 6 != c.length ? (d++, $("#user_shipping_postcode").parent().addClass("has-error")) : $("#user_shipping_postcode").parent().removeClass("has-error"), d > 0) return !1;
    var p = {
        customer_id: e,
        shipping_first_name: r,
        shipping_last_name: t,
        shipping_address_1: a,
        shipping_address_2: o,
        shipping_mobile: n,
        shipping_landline: s,
        shipping_city: l,
        shipping_state: i,
        shipping_pincode: c
    };
    $.ajax({
        type: "POST",
        url: host_url + "/editshippinginfo",
        data: p,
        beforeSend: function(e) {
            $("#address_submit").html("Please Wait...")
        },
        success: function(e) {
            e ? $(location).attr("href", "myaccount") : $("#shipping_address_error_msg").html("Error occured in shipping address")
        }
    })
}), $(".choice_return").on("click", function() {
    var e = $(this).attr("rel");
    $("#" + e).addClass("strike");
    var r = $(this).attr("pid");
    $("#return_msg_" + r).html("Select at least one reason for return"), $("#review_" + r).html('<span class="label label-danger">Return</span>')
}), $(".choice_keep").on("click", function() {
    var e = $(this).attr("rel");
    $("#" + e).removeClass("strike");
    var r = $(this).attr("pid");
    $("#return_msg_" + r).html(""), $("#review_" + r).html('<span class="label label-success">Kept</span>')
}), $("#edit_profile_personal_info").on("click", function() {
    var e = $("#edit_first_name").val(),
    r = $("#edit_last_name").val(),
    t = 0;
    if ("" == e || null == e ? (t++, $("#edit_first_name").parent().addClass("has-error")) : $("#edit_first_name").parent().removeClass("has-error"), "" == r || null == r ? (t++, $("#edit_last_name").parent().addClass("has-error")) : $("#edit_last_name").parent().removeClass("has-error"), t > 0) return !1;
    var a = {
        edit_first_name: e,
        edit_last_name: r
    };
    $.ajax({
        type: "POST",
        url: host_url + "/savebasicinfo",
        data: a,
        beforeSend: function(e) {
            $("#edit_profile_personal_info").prop("disabled", !0), $("#edit_profile_personal_info").html("Please Wait...")
        },
        success: function(e) {
            0 == e.error ? $(location).attr("href", "myaccount") : $(location).attr("href", "login")
        }
    })
}), $("#edit_profile_change_password").on("click", function() {
    var e = $("#edit_oldPswd").val(),
    r = $("#edit_newPswd").val(),
    t = $("#edit_confirmPswd").val(),
    a = 0;
    if ("" == e || null == e ? (a++, $("#edit_oldPswd").parent().addClass("has-error")) : $("#edit_oldPswd").parent().removeClass("has-error"), "" == r || null == r ? (a++, $("#edit_newPswd").parent().addClass("has-error")) : $("#edit_newPswd").parent().removeClass("has-error"), r != t ? (a++, $("#edit_confirmPswd").parent().addClass("has-error")) : $("#edit_confirmPswd").parent().removeClass("has-error"), a > 0) return !1;
    var o = {
        edit_oldPswd: e,
        edit_newPswd: r
    };
    $.ajax({
        type: "POST",
        url: host_url + "/savepassword",
        data: o,
        beforeSend: function(e) {
            $("#edit_profile_change_password").prop("disabled", !0), $("#edit_profile_change_password").html("Please Wait...")
        },
        success: function(e) {
            0 == e.error ? $(location).attr("href", "myaccount") : 2 == e ? ($("#updatePswd_error").html("Old Password Mismatch").css("color", "#FF0000"), $("#edit_profile_change_password").prop("disabled", !1), $("#edit_profile_change_password").html("Save")) : $(location).attr("href", "myaccount")
        }
    })
}), $("#address_edit_submit").on("click", function() {
    var e = $("#span_customer_id").attr("rel"),
    r = $("#shipping_first_name").val(),
    t = $("#shipping_last_name").val(),
    a = $("#shipping_address_1").val(),
    o = $("#shipping_address_2").val(),
    n = $("#shipping_mobile").val(),
    s = $("#shipping_landline").val(),
    l = $("#shipping_city").val(),
    i = $("#shipping_state").val(),
    c = $("#shipping_pincode").val(),
    d = 0;
    if ("" == r || null == r ? (d++, $("#shipping_first_name").parent().addClass("has-error")) : $("#shipping_first_name").parent().removeClass("has-error"), "" == t || null == t ? (d++, $("#shipping_last_name").parent().addClass("has-error")) : $("#shipping_last_name").parent().removeClass("has-error"), "" == a || null == a ? (d++, $("#shipping_address_1").parent().addClass("has-error")) : $("#shipping_address_1").parent().removeClass("has-error"), "" == n || null == n || 10 != n.length ? (d++, $("#shipping_mobile").parent().addClass("has-error")) : $("#shipping_mobile").parent().removeClass("has-error"), "" == l || null == l ? (d++, $("#shipping_city").parent().addClass("has-error")) : $("#shipping_city").parent().removeClass("has-error"), "" == i || null == i ? (d++, $("#shipping_state").parent().addClass("has-error")) : $("#shipping_state").parent().removeClass("has-error"), isNaN(c) || "" == c || null == c || 6 != c.length ? (d++, $("#shipping_pincode").parent().addClass("has-error")) : $("#shipping_pincode").parent().removeClass("has-error"), d > 0) return !1;
    var p = {
        customer_id: e,
        shipping_first_name: r,
        shipping_last_name: t,
        shipping_address_1: a,
        shipping_address_2: o,
        shipping_mobile: n,
        shipping_landline: s,
        shipping_city: l,
        shipping_state: i,
        shipping_pincode: c,
        ajax: 6
    };
    $.ajax({
        type: "POST",
        url: host_url + "ajax.php",
        data: p,
        beforeSend: function(e) {
            $("#address_submit").prop("disabled", !0), $("#address_submit").html("Please Wait...")
        },
        success: function(e) {
            1 == e ? $(location).attr("href", "my_account.php") : $("#shipping_address_error_msg").html("Error occured in shipping address")
        }
    })
}), $("#method_cod").on("click", function() {
    $(".cod-note").css("display", "block"), $(".online-note").css("display", "none")
}), $("#method_online").on("click", function() {
    $(".cod-note").css("display", "none"), $(".online-note").css("display", "block")
}), $("#online_payment").on("click", function() {
    var e = {
        ajax: 8
    };
    $.ajax({
        type: "POST",
        url: host_url + "ajax.php",
        data: e,
        beforeSend: function(e) {},
        success: function(e) {
            0 != e || alert("Payment Gateway Error.")
        }
    })
}), $("#refund_cashback").on("click", function() {
    $("#refund_bank_account").parent().removeClass("active"), $(this).parent().addClass("active"), $("#bank_details").addClass("hide"), $(".refund_cashback_confirm_button").removeClass("hide")
}), $("#refund_bank_account").on("click", function() {
    $("#refund_cashback").parent().removeClass("active"), $(this).parent().addClass("active"), $("#bank_details").removeClass("hide"), $(".refund_cashback_confirm_button").addClass("hide")
}), $("#refund_cashback_confirm_button").on("click", function() {
    var e = $("input:radio[name=refund_mode]:checked").val();
    $(this).hide();
    var r = {
        refund_mode: e
    };
    $.ajax({
        type: "POST",
        url: host_url + "/refundStoreCredit",
        data: r,
        beforeSend: function(e) {
            $("#bank_account_div").addClass("hide")
        },
        success: function(e) {
            console.log(e), 0 != e ? $("#layout-content-primary").html('Thanks for leaving your valuable feedback.<br><br>RETURNS PROCEDURE:<br><br>We\'ve made returns easy and hassle free for all of you. kindly follow the below steps:<br><br>Find the <strong>"2 PREPAID RETURNS SHIPPING LABEL"</strong> provided in the plastic bag inside the box.<br><br>1. Repack any returns in the same box with all the original packaging materials intact.<br><br>2.  Keep the "2 PREPAID RETURNS SHIPPING LABEL" on the TOP/OUTSIDE the box, so that the courier partner will know that you have the returns shipping label at the time of pick up. (You\'ll find 2 shipping labels in the plastic bag inside the BOX)<br><br><strong>"IT IS IMPORTANT TO KEEP THE SHIPPING LABELS ON THE TOP/OUTSIDE THE BOX"</strong><br><br>3.  Kindly hand over the "BOX" and only the <strong>"2 PREPAID RETURNS SHIPPING LABEL"</strong> at the time of pick up.<br><br>NOTE: <br><br>1. Do not fill any manual form provided by FED EX at the time of pick up.  If in case, the delivery person asks to fill the manual form and sign, kindly call us on 09769880806 to let us know and we\'ll resolve it from our side. We\'ll not entertain any returns if it comes in "MANUAL FORM" other than with the shipping label provided inside the box. Returns received other than shipping label (on FED EX priority plan) will be charged as per actuals in the plan selected.<br><br>2. Do not hand over original Invoice and any other paper/copies while returning, it is for you to keep.<br><br>You\'ll receive an E-mail and Sms once the returns are arranged on the date we have scheduled the reverse pick up.<br><br>Thanks.<br><br>If you have any queries reach us on <strong>09769880806</strong> and we will be happy to assist you.') : $("#layout-content-primary").html("Please try again after sometime.")
        }
    })
}), $("#refund_confirm_button").on("click", function() {
    var e = $("#first_name").val(),
    r = $("#last_name").val(),
    t = $("#bank_name").val(),
    a = $("#bank_ifc_code").val(),
    o = $("#account_no").val(),
    n = $("#reenter_account_no").val(),
    s = "",
    l = $("#ba_confirmation").is(":checked"),
    i = 0;
    if ("" == e || null == e ? (i++, $("#first_name").addClass("err")) : $("#first_name").removeClass("err"), "" == r || null == r ? (i++, $("#last_name").addClass("err")) : $("#last_name").removeClass("err"), "" == t || null == t ? (i++, $("#bank_name").addClass("err")) : $("#bank_name").removeClass("err"), "" == a || null == a || 11 != a.length ? (i++, $("#bank_ifc_code").addClass("err")) : $("#bank_ifc_code").removeClass("err"), "" == o || null == o || o.length <= 0 ? (i++, $("#account_no").addClass("err")) : $("#account_no").removeClass("err"), "" == n || null == n || n != o ? (i++, $("#account_no").addClass("err"), $("#reenter_account_no").addClass("err"), $("#bank_account_err_msg").html("Account number mismatch.").css("color", "red")) : ($("#account_no").removeClass("err"), $("#reenter_account_no").removeClass("err")), l ? ($("#ba_confirmation").attr("style", ""), $("#bank_account_err_msg").html("")) : (i++, $("#ba_confirmation").attr("style", "outline:2px solid #c00;"), $("#bank_account_err_msg").html("Please confirm your Bank Details.").css("color", "red")), i > 0) return !1;
    var c = {
        refund_mode: "Bank Account",
        first_name: e,
        last_name: r,
        bank_name: t,
        bank_ifc_code: a,
        account_no: o,
        branch: s,
        ajax: 10
    };
    $.ajax({
        type: "POST",
        url: host_url + "/refundBankAccount",
        data: c,
        beforeSend: function(e) {
            $("#cashback_div").addClass("hide")
        },
        success: function(e) {
            0 != e ? $("#layout-content-primary").html('Thanks for leaving your valuable feedback.<br><br>RETURNS PROCEDURE:<br><br>We\'ve made returns easy and hassle free for all of you. kindly follow the below steps:<br><br>Find the <strong>"2 PREPAID RETURNS SHIPPING LABEL"</strong> provided in the plastic bag inside the box.<br><br>1. Repack any returns in the same box with all the original packaging materials intact.<br><br>2. Keep the "2 PREPAID RETURNS SHIPPING LABEL" on the TOP/OUTSIDE the box, so that the courier partner will know that you have the returns shipping label at the time of pick up. (You\'ll find 2 shipping labels in the plastic bag inside the BOX)<br><br><strong>"IT IS IMPORTANT TO KEEP THE SHIPPING LABELS ON THE TOP/OUTSIDE THE BOX"</strong>3. Kindly hand over the "BOX" and only the <strong>"2 PREPAID RETURNS SHIPPING LABEL"</strong> at the time of pick up.<br><br>NOTE: <br><br>1. Do not fill any manual form provided by FED EX at the time of pick up.  If in case, the delivery person asks to fill the manual form and sign, kindly call us on 09769880806 to let us know and we\'ll resolve it from our side. We\'ll not entertain any returns if it comes in "MANUAL FORM" other than with the shipping label provided inside the box. Returns received other than shipping label (on FED EX priority plan) will be charged as per actuals in the plan selected.<br><br>2. Do not hand over original Invoice and any other paper/copies while returning, it is for you to keep.<br><br>Youâ€™ll receive an E-mail and Sms once the returns are arranged on the date we have scheduled the reverse pick up.<br><br>Thanks.<br><br>If you have any queries reach us on <strong>09769880806</strong> and we will be happy to assist you.') : $("#layout-content-primary").html("Please try againg after sometime.")
        }
    })
}), $(".gift_price").on("click", function() {
    "other" == $(".gift_price:checked").val() ? $("#card_price_other").prop("disabled", !1) : ($("#card_price_other").val("0"),
    $("#card_price_other").prop("disabled", !0))
}), $('input[name="auto_ship"]').unbind().click(function() {
    "checkshipment" == $(this).attr("value") && $("#displayfrequency").toggle()
}), $("#confirm_refer").on("click", function() {
    var e = {
        confirm: "yes"
    };
    $.ajax({
        type: "POST",
        url: host_url + "/refer_confirm",
        data: e,
        beforeSend: function(e) {
            $("#confirm_refer").attr("disabled", !0), $("#confirm_refer").val("Please wait...")
        },
        success: function(e) {
            1 == e ? $("#conf_msg").html("Referal sent succesfully") : $("#conf_msg").html("Something went wrong"), $("#confirm_refer").attr("disabled", !1), $("#confirm_refer").val("Confirm")
        }
    })
}), $("#referal_code_signup").keyup(function() {
    var e = $(this).val();
    e.length >= 5 ? (ajax_reg_data = {
        referalcode: e
    }, $.ajax({
        type: "POST",
        url: host_url + "/validateReferalCode",
        data: ajax_reg_data,
        success: function(e) {
            1 == e ? ($("#referal_code_signup_succ").html("Looks correct code"), $("#referal_code_signup_error").html("")) : ($("#referal_code_signup_succ").html(""), $("#referal_code_signup_error").html("Invalid code entered"))
        }
    })) : ($("#referal_code_signup_error").html(""), $("#referal_code_signup_succ").html(""))
}),  $(".fb_mess_mob").on("click", function() {
    var e = $("#refer_code_value").val(),
    r = "1652112848427730";
    window.open("fb-messenger://share?link=" + encodeURIComponent("http://test.snobbox.in/ref-" + e) + "&app_id=" + encodeURIComponent(r))
}), $(".fb_mess_desk").on("click", function() {
    var e = $("#refer_code_value").val();
    FB.ui({
        method: "send",
        link: "http://test.snobbox.in/ref-" + e
    }, function(e) {})
}), $("#invMobbtn").on("click", function() {
    var e = $("#sms_ref").val(),
    r = new Array,
    t = 0,
    a = /^[0-9]*$/,
    o = 0;
    e.indexOf(",") > 0 ? r = e.split(",") : r[0] = e;
    for (var n = 0; n < r.length; n++) a.test(r[n]) && "" != r[n] && null != r[n] || t++, o++;
    if (0 != t) $("#sms_ref").addClass("pin-error"), $("#ref_error_msg").html("Invalid mobile no entered");
    else if (o > 5) $("#ref_error_msg").html("You are exceeding max reference limit of 5");
    else {
        $("#sms_ref").removeClass("pin-error"), $("#ref_error_msg").html(""), $("#ref_type").val("mobile");
        var s = $("#sms_ref").val(),
        l = "mobile",
        i = {
            ref_sms_csv: s,
            ref_type: l
        };
        $.ajax({
            type: "POST",
            url: host_url + "/saveReferNowData",
            data: i,
            success: function(e) {
                1 == e ? ($("#confirm_refer").prop("disabled", !1), $("#confirm_refer").html("Confirm"), $(".curr_msg").html(""), $("#conf_msg").html(""), $("#refernow_msg").html(s.replace(",", "<br>")), $("#myModalconfirm").modal("show")) : $("#ref_error_msg").html("Something went wrong")
            }
        })
    }
}), $(".ui.facebook.button").click(function() {
    var e = $("#refer_code_value").val();
    FB.ui({
        method: "share",
        href: host_url + "/ref-" + e,
        name: "SnobBox.com",
        picture: "http://marketingland.com/wp-content/ml-loads/2014/08/share-signs-ss-1920-800x450.jpg",
        caption: "Sign up and get free order",
        description: "Personalised style for women"
    }, function(e) {})
}), $("#styling_fee").on("click", function() {
    $("#pl_ordid").attr("d"), $("#sty_fee").attr("d");
    $.ajax({
        type: "POST",
        url: host_url + "/stylingfees_paymentRequest",
        data: null,
        beforeSend: function(e) {
            $("#styling_fee").prop("disabled", !0), $("#styling_fee").html("Please Wait...")
        },
        success: function(e) {
            $("#redirect").html(e)
        }
    })
}), $("#pl_styling_fee").on("click", function() {
    $("#pl_ordid").attr("d");

    var payGateway = 'paytm';
    payGateway = $('input[name=paymentGatewayMethod]:checked').val();
    //alert(payGateway);return false;

    var ajax_data = {
        payGateway: payGateway
    }

    $.ajax({
        type: "POST",
        url: host_url + "/paylater_paymentRequest",
        data: ajax_data,
        beforeSend: function(e) {
            $("#pl_styling_fee").prop("disabled", !0), $("#pl_styling_fee").html("Please Wait...")
        },
        success: function(e) {
            console.log(e);
            $("#pl_redirect").html(e)
        }
    })
}), $("body").unbind("click").on("click", ".occassion-label", function() {
    var e = $(this).attr("id");
    $("#" + e).hasClass("active") ? $("#" + e).removeClass("active") : $("#" + e).addClass("active")
}), $("#pl_online").on("click", function() {
    var e = $("#pl_keptprice").attr("d");
    var payGateway = 'paytm';
    payGateway = $('input[name=paymentGatewayMethod]:checked').val();
    //alert(payGateway);return false;
    r = {
        amount: e,
        payGateway: payGateway,
    };
    $.ajax({
        type: "POST",
        url: host_url + "/pl_payment_online",
        data: r,
        beforeSend: function(e) {
            $("#pl_online").prop("disabled", !0), $("#pl_online").html("Please Wait...")
        },
        success: function(e) {
            //console.log(e);return false;
            //console.log(e), $("#pl_redirect").html(e)

            //alert(payGateway);return false;
            if(payGateway == 'paytm') {
                if (e.error == false) {
                    window.history.forward();
                    function noBack() { window.history.forward(); }

                    //$("#complete_snobbox").attr("disabled", false);
                    //$('#complete_snobbox').val('Complete Your SnobBox');
                    //alert(e.payment_flag);return false;
                    if(e.payment_flag == 1) {
                        $('#pl_redirect').html(e.url);
                        //$('body').html(e.url);
                    }
                    else {
                        $(location).attr('href', 'paylater_payment');
                    }
                } else {
                    $(location).attr('href', 'schedule');
                    $('#snobbox_div').html('Some error occured');
                }
            }
            else {
                console.log(e), $("#pl_redirect").html(e)
            }

        }
    })
}), $("#pl_cod").on("click", function() {
    $.ajax({
        type: "POST",
        url: host_url + "/pl_payment_cod",
        data: null,
        success: function(e) {
            window.location.href = "schedule"
        }
    })
}), $("#returnPolicy_online").on("click", function() {
    $("#returnPolicyContent_online").html('<span class="instructions instructional-note online-main-note" style="font-weight:bold;font-size:16px"><ul type="circle"><li style="list-style-type: disc;"> In case of any returns, log in to your SnobBox account within 2 days of delivery, and checkout online with the feedback for the products you\'d like to return.</li> <br><li type="Disc" style="list-style-type: disc;">Once we receive your checkout, you\'ll be eligible to receive refunds for the returned products via Bank transfer within 2-3 working days, after we receive the returns.</li> <br><li type="Disc" style="list-style-type: disc;">Alternatively, you can also keep the amount as store credits for your next SNOBBOX.</li><br></ul>')
}), $("#returnPolicy_cod").on("click", function() {
    $("#returnPolicyContent_cod").html('<span class="instructions instructional-note cod-main-note" style="font-weight:bold;font-size:16px"><ul type="circle"><li style="list-style-type: disc;">In case of any returns, log in to your SnobBox account within 2 days of delivery, and checkout online with the feedback for the products you\'d like to return.</li> <br><li type="Disc" style="list-style-type: disc;">Once we receive your checkout, you\'ll be eligible to receive refunds for the returned products via Bank transfer within 2-3 working days, after we receive the returns.</li><br><li type="Disc" style="list-style-type: disc;">Alternatively, you can also keep the amount as store credits for your next SNOBBOX.</li><br></ul>')
}), $("#orderPayment").on("click", function() {
    var payGateway = 'paytm';
    payGateway = $('input[name=paymentGatewayMethod]:checked').val();
    //alert(payGateway);return false;
    var e = $("#op_link").attr("d"),
    r = $("#op_paymentLink_flag_insertedId").attr("d");
    ajax_data = {
        link: e,
        paymentLink_flag_insertedId: r,
        payGateway: payGateway
    }, $.ajax({
        type: "POST",
        url: host_url + "/paymentRequest" + e,
        data: ajax_data,
        success: function(e) {
            //console.log(e);return false;
            $("#op_redirect").html(e)
        }
    })
}), $(".requires-snobbox-date").on("click", function() {
    var e = $(this).attr("id");
    e = e.trim();
    try {
        window[e]()
    } catch (r) {}
}), $("body").unbind().on("click", "#add_note", function() {
    $("#add_note").prop("disabled", !0), $("#add_note").html("Please Wait...");
    var e = $("textarea#snobbox_note").val();
    ajax_data = {
        note: e
    }, $.ajax({
        type: "POST",
        url: host_url + "/add_note",
        data: ajax_data,
        success: function(e) {
            e ? location.reload() : ($("#note_msg").html("Error occured while adding note. Please try again after sometime."), $("#add_note").prop("disabled", !1), $("#add_note").html("ADD NOTE"))
        }
    })
}), $(function() {
    var e, r, t, a;
    $(".ripplelink").click(function(o) {
        $(".card").removeClass("card-active");
        $(this).attr("rel");
        0 === $(this).find(".ink").length && $(this).prepend("<span class='ink'></span>"), e = $(this).find(".ink"), e.removeClass("animate"), e.height() || e.width() || (r = Math.max($(this).outerWidth(), $(this).outerHeight()), e.css({
            height: r,
            width: r
        })), t = o.pageX - $(this).offset().left - e.width() / 2, a = o.pageY - $(this).offset().top - e.height() / 2, e.css({
            top: a + "px",
            left: t + "px"
        }).addClass("animate"), $(this).parent().addClass("card-active"), $(".card").css("border", "border: 7px solid #3b857a;position: relative;display: block;margin-bottom: .75rem;background-color: #fff;border-radius: .25rem;");
        var n = $(this).attr("rel");
        if ($("#bType").attr("rel", n), $("#scheduleBox").removeClass("hidden"), $("#bloggercontent").html(""), "Santoshi" == n) $(".blogger_work").html("Santoshi"), $("#currentbloggercontent").hide(), $("#bloggercontent").html('"Introducing Limited Edition Boxes" The same service that you know & love, now gives you an exciting opportunity to get personally styled by your very own favourite blogger - Santoshi Shetty<br> Yes Yes, you heard that right <span style="width:10px"><img src="../images/sq/hearticon.png" style="width:2%;"></span> <span style="width:10px"><img src="../images/sq/hearticon.png" style="width:2%;"></span>'), $("#bloggerschedulecontent").show(), $("#normalschedule").hide(), $("#receiveline").hide(), $("#paylaterschedule").hide(), $("#payLaterCheck_error").hide(), $("#bloggercontent").show(), $("#bloggertagline").show(), $("#normaldelivery").hide(), $("#limitedslot").show(), $("#blogger_delivery").show(), $("#setBDate").removeClass("hidden"), $("#datepicker").addClass("hidden"), $("#setfrequency").addClass("hidden"), $(".requires-snobbox-date").attr("id", "blogger_schedule_snobbox"), $("#schedule_title").hide(), $("#bNote").html('<br>Santoshi is known for her edgy, sporty, bold and experimental style and she’ll be styling the limited edition boxes from our wide catalogue of the above mentioned styles only. So, if you love the way she styles and flaunts her look, book your SNOBBOX before anyone else <span style="width:10px"><img src="../images/sq/hearticon.png" style="width:2%;"></span>'), $(".bName").html("Santoshi"), $(".bloggerNameJuhi").addClass("hide"), $(".bloggerNameSantoshi").removeClass("hide"), $("#freq_note").addClass("hide");
        else if ("Juhi" == n) $(".blogger_work").html("Juhi"), $("#currentbloggercontent").hide(), $("#bloggercontent").html('"Introducing Limited Edition Boxes" The same service that you know & love, now gives you an exciting opportunity to get personally styled by your very own favourite blogger - Juhi Godambe<br> Yes Yes, you heard that right <span style="width:10px"><img src="../images/sq/hearticon.png" style="width:2%;"></span> <span style="width:10px"><img src="../images/sq/hearticon.png" style="width:2%;"></span>'), $("#bloggerschedulecontent").show(), $("#normalschedule").hide(), $("#receiveline").hide(), $("#paylaterschedule").hide(), $("#payLaterCheck_error").hide(), $("#bloggercontent").show(), $("#bloggertagline").show(), $("#normaldelivery").hide(), $("#limitedslot").show(), $("#blogger_delivery").show(), $("#payLaterCheck_error").hide(), $("#setBDate").removeClass("hidden"), $("#datepicker").addClass("hidden"), $("#setfrequency").addClass("hidden"), $(".requires-snobbox-date").attr("id", "blogger_schedule_snobbox"), $("#schedule_title").hide(), $("#bNote").html('<br>Juhi is known for chic, classy, elegant and uptown style and she’ll be styling the limited edition boxes from our wide catalogue of the above mentioned styles only. So, if you love the way she styles and flaunts her look, book your SNOBBOX before anyone else <span style="width:10px"><img src="../images/sq/hearticon.png" style="width:2%;"></span>'), $(".bName").html("Juhi"), $(".bloggerNameSantoshi").addClass("hide"), $(".bloggerNameJuhi").removeClass("hide"), $("#freq_note").addClass("hide");
        else {
            $("#schedule_title").show(), $("#bloggerschedulecontent").hide(), $("#payLaterCheck_error").hide(), $("#paylaterschedule").show(), $("#bloggercontent").show(), $("#bloggertagline").hide(), $("#normaldelivery").show(), $("#blogger_delivery").hide(), $("#limitedslot").hide(), $("#normalschedule").show(), $("#receiveline").show(), $("#currentbloggercontent").hide(), $("#setBDate").addClass("hidden"), $("#datepicker").removeClass("hidden"), $("#setfrequency").removeClass("hidden"), $(".requires-snobbox-date").attr("id", "schedule_snobbox");
            var s = $.urlParam("paylater");
            "yes" == s && ($("#bloggercontent").html('Congratulation, It’s your lucky day! Our <strong>"Try First, Pay Later Service"</strong> is available for your PINCODE. This premium service allows you to try the handpicked pieces by your personal stylist for a day and pay later on the next day. Sounds exciting? Go ahead and schedule your SnobBox. (Limited period offer)<br>'), $("#paylaterschedule").html('<p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">1. Schedule your surprise SnobBox and on call styling consultancy with our in-house expert stylist by paying a styling fee of Rs.199 online</p><p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">2. Post which she\'ll get in touch with you via a phone call to learn more about your style preferences & share her expert knowledge about the new fashion trends to experiment with.</p><p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">3. She\'ll personally handpick a minimum of 10 trendy and experimental pieces to fit your preferences, delivered to your doorstep. (Categories - western clothing, jewellery and bags)</p><p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">4. You get one day to try everything within the comfort of your home. Keep anything, everything or nothing. We\'ll charge you only for what you keep.</p><br><strong>EASY RETURNS:</strong><br><br><p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">1. Log in to your SnobBox account upon delivery and complete the checkout feedback process online.</p><p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">2. A payment link with the amount of the products you keep will be generated to pay online.</p><p class="instructional-note" style="font-size:15px; list-style-type: decimal !important;">3. Once you make the payment, the merchandise you wish to return will be picked up with the same packaging the very next day.<br><br></p><span class="bold" style="border-bottom: 1px solid #ccc;color: black;border-top: 1px solid #ccc;font-size: 16px;font-family: "BrandonText-Regular", sans-serif;">Styling Fee Rs. 199| Free Shipping | Free Returns | 2 Days Free Home Trial | Only pay for what you keep</span><br>'))
        }
        $("#bloggercontent").scrollView2("75")
    })
})
}),
function(e) {
    e.fn.rating = function(r, t) {
        function a(r) {
            rating = parseInt(r.attr("data-rating")), r.find("input").val(rating), r.find("span.ratingicon").each(function() {
                var r = parseInt(e(this).parent().attr("data-rating")),
                t = parseInt(e(this).attr("data-value"));
                t > r ? e(this).css("color", o.coloroff) : e(this).css("color", o.coloron)
            })
        }
        r = r || "create";
        var o = e.extend({
            limit: 5,
            value: 0,
            glyph: "glyphicon-star",
            coloroff: "gray",
            coloron: "#69BDB0",
            size: "2.0em",
            cursor: "default",
            onClick: function() {},
            endofarray: "idontmatter"
        }, t),
        n = "";
        if (n = n + "font-size:" + o.size + "; ", n = n + "color:" + o.coloroff + "; ", n = n + "cursor:" + o.cursor + "; ", "create" == r) {
            this.each(function() {
                attr = e(this).attr("data-rating"), (void 0 === attr || attr === !1) && e(this).attr("data-rating", o.value)
            });
            for (var s = 0; s < o.limit; s++) this.append('<span data-value="' + (s + 1) + '" class="ratingicon glyphicon ' + o.glyph + '" style="' + n + '" aria-hidden="true"></span>');
            this.each(function() {
                a(e(this))
            })
        }
        return "set" == r && (this.attr("data-rating", t), this.each(function() {
            a(e(this))
        })), "get" == r ? this.attr("data-rating") : void this.find("span.ratingicon").click(function() {
            rating = e(this).attr("data-value"), e(this).parent().attr("data-rating", rating), a(e(this).parent()), o.onClick.call(e(this).parent())
        })
    }
}(jQuery), $(document).ready(function() {
    $("#stars-default").rating(), $("#stars-green").rating("create", {
        coloron: "green",
        onClick: function() {
            alert("rating is " + this.attr("data-rating"))
        }
    }), $("#stars-herats").rating("create", {
        coloron: "red",
        limit: 10,
        glyph: "glyphicon-heart"
    })
}), $(function() {
    function e() {
        return /(iPhone).OS [1-5](.) like Mac OS X/i.test(navigator.userAgent) || /(iPod).OS [1-6](.) like Mac OS X/i.test(navigator.userAgent) || /(iPad).OS [1-4](.) like Mac OS X/i.test(navigator.userAgent)
    }
    if ($("body.public-home").length) {
        var r = function() {
            var e = $(".global-nav-placeholder").offset().top,
            t = $(document).scrollTop();
            $("body").toggleClass("global-nav-fixed", t > e), setTimeout(r, 1e3)
        };
        setTimeout(r, 1e3), setTimeout(function() {
            e() ? $("body").addClass("no-fixed-background") : ($("body.public-home .wrapper").append('<section class="bg"></section>'), $("body").addClass("fixed-background"))
        }, 2900)
    }




    /* Nirmeet refernow confirm popup start*/
    $('#invEmailbtn').on('click', function() {
        var ref_email_csv = $('#email_ref').val();
        var ref_emil_arr = new Array();
        var error_flag = 0;
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
        var presentRefCnt = 0;

        if( ref_email_csv.indexOf(',') > 0)
        {
            ref_emil_arr = ref_email_csv.split(",");
        }
        else
        {
            ref_emil_arr[0] = ref_email_csv;
        }
        // console.log(ref_emil_arr[0]);return false;

        for (var i = 0; i < ref_emil_arr.length; i++)
        {
            if (!(emailPattern.test(ref_emil_arr[i])) || ref_emil_arr[i] == '' || ref_emil_arr[i] == null)
            {
                error_flag++;
                //console.log(ref_emil_arr[i]);
            }
            presentRefCnt++;
        }

        if(error_flag!=0)
        {
            $('#email_ref').addClass('pin-error');
            $('#ref_error_msg').html('Invalid email entered');
        }
        else if(presentRefCnt>5)
        {
            $('#ref_error_msg').html('You are exceeding max reference limit of 5');
        }
        else
        {
            $('#email_ref').removeClass('pin-error');
            $('#ref_error_msg').html('');

            $('#ref_type').val('email')
            var ref_email_csv = $('#email_ref').val();
            var ref_type = 'email';
            //alert(ref_email_csv);
            var ajax_data = {
                ref_email_csv : ref_email_csv,
                ref_type : ref_type,
            }

            $.ajax({
                type : "POST",
                url : host_url + '/saveReferNowData',
                data : ajax_data,
                success: function(result) {
                    if(result==1)
                    {
                        $('#confirm_refer').prop('disabled', false);
                        $('#confirm_refer').html('Confirm');
                        $('.curr_msg').html('');
                        $('#conf_msg').html('');
                        $('#refernow_msg').html(ref_email_csv.replace(",", "<br>"));
                        $('#confirm_refer').val('Confirm');
                        $('#confirm_refer').show();
                        $('#myModalconfirm').modal('show');
                    }
                    else
                    {
                        $('#ref_error_msg').html('Something went wrong');
                    }
                }
            });
        }
    });



    /* Refer Nirmeet start */
    $('#confirm_refer').on('click', function() {
        // var ref_email_csv = $('#ref_email_csv').val();
        // var ref_type = $('#ref_type').val();
        var ajax_data = {
            confirm:'yes',
        }
        $.ajax({
            type: "POST",
            url: host_url + '/refer_confirm',
            data: ajax_data,
            beforeSend: function(result) {
                $("#confirm_refer").attr("disabled", true);
                $('#confirm_refer').val('Please wait...');
            },
            success: function(result) {
                console.log();//return false;
                if (result == 1)
                {
                    $('#conf_msg').html('Referal sent succesfully');
                }
                else
                {
                    $('#conf_msg').html('Something went wrong');
                }

                //$("#confirm_refer").attr("disabled", false);
                //$('#confirm_refer').val('Confirm');
                $('#confirm_refer').hide();
            }
        });
    });


    /* Generate OTP */
    $('#generate_otp').on('click', function() {

        var mobile = $('#user_mobile').val();
        var country = $('#country').val();
        // console.log(country);

        var flag = 0;

        switch (country) {
            case 1:
                var phonePattern = /^[0-9]*$/;
            break;
            case 2:
                var phonePattern = /^[0-9]*$/;
            break;
            default:
                var phonePattern = /^[0-9]*$/;

        }

        if(mobile=='' ||  mobile==null || !phonePattern.test(mobile) )
        {
            $('#user_mobile').addClass('error');
            flag++;
        }
        else
        {
            $('#user_mobile').removeClass('error');
        }

        if( country=='' ||  country==null)
        {
            $('#country').addClass('error');
            flag++;
        }
        else
        {
            $('#country').removeClass('error');
        }

        if(flag == 0 )
        {
            var ajax_data = {
                mobile:mobile,
                country:country,
            }
            $.ajax({
                type: "POST",
                url: host_url + '/generate_otp',
                data: ajax_data,
                beforeSend: function() {
                    $("#generate_otp").attr("disabled", true);
                    $('#generate_otp').val('Please wait...');
                    $('#login_message').html('');
                },
                success: function(result) {
                    if (result.error == false)
                    {
                        $("#generate_otp").attr("disabled", false);
                        $('#generate_otp').val("Let's Begin");

                        if( result.user_exeists == 1)
                        {
                            //user exist ,show verify otp form
                            $('.otp-field , .login-field').removeClass('hidden');
                            $('.gene-otp-field ').addClass('hidden');
                            $('.tel-gr').attr("disabled", true);

                        }
                        else if( result.user_exeists == 0) {
                            //new user ,show verify otp form with register form
                            $('.otp-field , .reg-field ').removeClass('hidden');
                            $('.gene-otp-field ').addClass('hidden');
                            $('.tel-gr').attr("disabled", true);

                        }
                        else {
                            // something went wrong
                        }
                    }
                    else
                    {
                        // something went wrong
                    }
                }
            });
        }
    });
    /* END Generate OTP */

    /* Verify OTP & Login */
    $('#login_otp').on('click', function() {

        var mobile = $('#user_mobile').val();
        var otp = $('#otp').val();
        var flag = 0;

        if(mobile=='' ||  mobile==null)
        {
            $('#user_mobile').addClass('error');
            flag++;
        }
        else
        {
            $('#user_mobile').removeClass('error');
        }

        if(otp=='' ||  otp==null)
        {
            $('#otp').addClass('error');
            flag++;
        }
        else
        {
            $('#otp').removeClass('error');
        }

        if(flag == 0 )
        {
            var ajax_data = {
                mobile:mobile,
                otp:otp,
            }
            $.ajax({
                type: "POST",
                url: host_url + '/verify_otp_login',
                data: ajax_data,
                async:true,
                beforeSend: function() {
                    $("#login_otp").attr("disabled", true);
                    $('#login_otp').val('Please wait...');
                    $('#login_message').html('');
                    // alert('Yelooooooo');
                },
                success: function(result) {
                    // alert('heelllo');
                    if (result.error == false)
                    { $("#login_otp").attr("disabled", false);
                        $('#login_otp').val("Verify OTP & Login");

                        if( result.otp_valid == 1)
                        {
                            window.location = "/schedule";
                        }
                        else if( result.otp_valid == 0) {
                            $('#login_message').html('<div class="alert alert-danger" role="alert">Invalid OTP</div>');
                        }
                        else
                        {
                            $('#login_message').html('<div class="alert alert-danger" role="alert">Something went wrong</div>');
                        }
                    }
                    else
                    {
                        $('#login_message').html('<div class="alert alert-danger" role="alert">Something went wrong</div>');
                    }
                },
                error: function () {
                    // alert('asdadasdas');
                }
            });
        }
    });
    /* END Verify OTP & Login */


    /* Verify OTP & Register */
    $('#register_otp').on('click', function() {

        var mobile = $('#user_mobile').val();
        var otp = $('#otp').val();
        var first_name = $('#user_first_name').val();
        var last_name = $('#user_last_name').val();
        var email = $('#user_email').val();
        var flag = 0;

        var EmailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;

        if(first_name=='' ||  first_name==null)
        {
            $('#user_first_name').addClass('error');
            flag++;
        }
        else
        {
            $('#user_first_name').removeClass('error');
        }

        if(last_name=='' ||  last_name==null)
        {
            $('#user_last_name').addClass('error');
            flag++;
        }
        else
        {
            $('#user_last_name').removeClass('error');
        }

        if(last_name=='' ||  last_name==null)
        {
            $('#user_last_name').addClass('error');
            flag++;
        }
        else
        {
            $('#user_last_name').removeClass('error');
        }

        if(mobile=='' ||  mobile==null)
        {
            $('#user_mobile').addClass('error');
            flag++;
        }
        else
        {
            $('#user_mobile').removeClass('error');
        }

        if(otp=='' ||  otp==null)
        {
            $('#otp').addClass('error');
            flag++;
        }
        else
        {
            $('#otp').removeClass('error');
        }

        if(!EmailPattern.test(email) || email=='' ||  email==null)
        {
            $('#user_email').addClass('error');
            flag++;
        }
        else
        {
            $('#user_email').removeClass('error');
        }

        if(flag == 0 )
        {
            var ajax_data = {
                mobile:mobile,
                otp:otp,
                first_name:first_name,
                last_name:last_name,
                email:email,
            }
            $.ajax({
                type: "POST",
                url: host_url + '/verify_otp_register',
                data: ajax_data,
                beforeSend: function() {
                    $("#register_otp").attr("disabled", true);
                    $('#register_otp').val('Please wait...');
                    $('#login_message').html('');
                },
                success: function(result) {
                    if (result.error == false)
                    {
                        $("#register_otp").attr("disabled", false);
                        $('#register_otp').val("Verify OTP & Register");

                        if( result.otp_valid == 1)
                        {
                            window.location = "/style-quiz-first-page";
                        }
                        else if( result.otp_valid == 0) {
                            $('#login_message').html('<div class="alert alert-danger" role="alert">Invalid OTP</div>');
                        }
                        else if( result.otp_valid == 2) {
                            $('#login_message').html('<div class="alert alert-danger" role="alert">Email id alert taken</div>');
                        }
                        else
                        {
                            $('#login_message').html('<div class="alert alert-danger" role="alert">Something went wrong</div>');
                        }
                    }
                    else
                    {
                        // something went wrong
                    }
                }
            });
        }
    });
    /* END Verify OTP & Login */


    /**
     * Add Address on Shipping address page start
     */

     $('#add_address').on('submit', function(eve) {

         eve.preventDefault();

         var flag = 0;
         var data = {};

         $('.val-addr').each(function() {
             if($(this).val() == '' || $(this).val() == null )
             {
                 $(this).addClass('error');
                 flag++;
             }
             else
             {
                 data[$(this).attr('id')] = $(this).val();
                 $(this).removeClass('error');
             }
         });

         data['instruction'] = $('#instruction').val() != '' ? $('#instruction').val() : null;
         data['city_id'] = $('#city_id').val() != '' ? $('#city_id').val() : null;

         if(flag == 0)
         {
             $.ajax({
                 type: "POST",
                 url: host_url + '/add_shipping_address',
                 data: data,
                 beforeSend: function(result) {
                     $('#add_sub_btn').prop('disabled', true);
                     $('#add_sub_btn').html('Please Wait...');
                 },
                 success: function(result) {

                     $('.val-addr').val('');

                     $('#add_sub_btn').prop('disabled', false);
                     $('#add_sub_btn').html('Submit');

                     if (result == 1) {
                         $('#address_msg').html('Address Added');
                         window.setTimeout(function(){
                          location.reload();
                         }, 2000);
                     } else {

                         $('#address_msg').html('Some error occured. Please try again after some time.');
                     }
                 }
             });
         }
     });

    /**
     * Add Address on Shipping address page End
     */


    /**
     *  Add Submit Address on Shipping address page start
     */

     $('#address_submit').on('click', function(eve) {

         // eve.preventDefault();

         var address_id = $("input[name='address_id']:checked").val() != '' ? $("input[name='address_id']:checked").val() : null;

         if(address_id != null)
         {
             data = {
                        'address_id':address_id
                    };
             $.ajax({
                 type: "POST",
                 url: host_url + '/select_shipping_address',
                 data: data,
                 beforeSend: function(result) {
                     $('#address_submit').prop('disabled', true);
                     $('#address_submit').html('Please Wait...');
                 },
                 success: function(result) {

                     $('#address_submit').prop('disabled', false);
                     $('#address_submit').html('Submit');

                     if (result == 1)
                     {
                         window.location = 'orderreview';
                     }
                     else
                     {
                         $('#address_submit_msg').html('Some error occured. Please try again after some time.');
                     }
                 }
             });
         }
         else
         {
                $('#address_submit_msg').html('Please select address')
         }
     });

    /**
     *  Add Submit Address on Shipping address page End
     */


});
