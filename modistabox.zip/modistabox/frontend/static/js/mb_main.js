$(window).scroll(function(){
  if ($(window).scrollTop() >= 50) {
    $('#header').addClass('fixed_header');
   }
   else {
    $('#header').removeClass('fixed_header');
   }
});

// Trending Slider
$('#trending').on('changed.owl.carousel initialized.owl.carousel', function(event) {
    $(event.target)
      .find('.owl-item').removeClass('last')
      .eq(event.item.index + event.page.size - 1).addClass('last');
  }).owlCarousel({
  loop: true,
  margin: 0,
  nav: true,
  items: 3,
  navText: [
    "<i class='fas fa-chevron-left'></i>",
    "<i class='fas fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1
    },
    600: {
      items: 3
    },
    1000: {
      items: 3
    }
  }
});


// Mobile menu

$('.menu_icon').on("click", function(){
  $('.nav').toggleClass('open_nav');
  $(this).toggleClass('rotate_menu');
});

// Trending Slider
$('.owl-carousel').on('changed.owl.carousel initialized.owl.carousel', function(event) {
    $(event.target)
      .find('.owl-item').removeClass('last')
      .eq(event.item.index + event.page.size - 1).addClass('last');
  }).owlCarousel({
  loop: true,
  margin: 0,
  nav: true,
  dots: false,
  items: 1,
  navText: [
    "<i class='fas fa-chevron-left'></i>",
    "<i class='fas fa-chevron-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1
    },
    600: {
      items: 1
    },
    1000: {
      items: 1
    }
  }
});

// more and less show