$( function() {

    var host_url = location.protocol + "//" + location.host;

   $( "#dob" ).datepicker({
     changeMonth: true,
     changeYear: true,
     dateFormat: "dd-mm-yy",
     maxDate: "-1"
   });
   $( "#due_date" ).datepicker({
     changeMonth: true,
     changeYear: true,
     dateFormat: "dd-mm-yy",
     minDate: new Date()
   });

   $('input[name="special_occation"]').on('change',function(){
       // console.log('adadasdada');
       if( $('input[name="special_occation"]:checked').val() == 'pregnancy')
       {
           $('.maternity_qst').removeClass('hide');
       }
       else
       {
           $('.maternity_qst').addClass('hide');
       }
   });


   $('#style_quiz_first_page').on('submit',function(eve){
        eve.preventDefault();

        var flag = 0;
        var mat_flag = 0;
        var special_occation = $('input[name="special_occation"]:checked').val();

        var mobile_view = $('#mobile_view').val();

        flag = validate_class('val');

        if( special_occation == 'pregnancy' )
        {
            mat_flag = validate_class('mat_val');
        }

        if(flag == 0 && mat_flag == 0)
        {
            $.ajax({
                type : "POST",
                url : host_url + '/style-quiz-first-page',
                data: $('#style_quiz_first_page').serialize(),
                beforeSend : function() {
                    $('#message').html('<div class="alert alert-info" role="alert">Please wait..</div>');
                },
                success : function(result) {
                    $('#message').html('');
                    if(result == 1)
                    {
                        console.log(mobile_view);
                        if(mobile_view == 0)
                        {
                            window.location.href = "style-quiz-about-yourself"
                        }
                        else
                        {
                            window.location.href = "style-quiz-about-yourself-mobile"
                        }
                    }
                    else
                    {
                        $('#message').html('<div class="alert alert-danger" role="alert">Something went wrong..</div>');
                    }
                },
                error: function()
                {
                    $('#message').html('<div class="alert alert-danger" role="alert">Something went wrong..</div>');
                }
            });
        }
        else
        {
                // console.log('flag = '+flag+' mat = '+mat_flag);
        }
   });


   $('#style_quiz_about_yourself').on('submit',function(eve){
        eve.preventDefault();

        var flag = 0;

        flag = validate_class('val');
        var mobile_view = $('#mobile_view').val();

        if(flag == 0)
        {
            $.ajax({
                type : "POST",
                url : host_url + '/style-quiz-about-yourself',
                data: $('#style_quiz_about_yourself').serialize(),
                beforeSend : function() {
                    $('#message').html('<div class="alert alert-info" role="alert">Please wait..</div>');
                },
                success : function(result) {
                    if(result == 1)
                    {
                        if(mobile_view == 0)
                        {
                            window.location.href = "style-quiz-tops-and-dresses"
                        }
                        else
                        {
                            window.location.href = "style-quiz-tops-and-dresses-mobile"
                        }
                    }
                    else
                    {
                      $('#message').html('<div class="alert alert-danger" role="alert">Something went wrong..</div>');
                    }
                },
                error: function() {
                    $('#message').html('<div class="alert alert-danger" role="alert">Something went wrong..</div>');
                }
            });
        }
        else
        {
                // console.log('flag = '+flag+' mat = '+mat_flag);
        }
   });

   $('#style_quiz_tops_dresses').on('submit',function(eve){
        eve.preventDefault();

        var mobile_view = $('#mobile_view').val();

        if(mobile_view == 0)
        {
            window.location.href = "style-quiz-bottom";
        }
        else
        {
            window.location.href = "style-quiz-bottom-mobile";
        }

        var flag = 0;
        var mat_flag = 0;

        // flag = validate_class('val');
        // console.log(flag); return false;
        // if( $('#special_occation').val() == 'pregnancy' )
        // {
        //     mat_flag = validate_class('mat_val');
        // }

        if(flag == 0 && mat_flag == 0)
        {
            $.ajax({
                type : "POST",
                url : host_url + '/style-quiz-tops-and-dresses',
                data: $('#style_quiz_tops_dresses').serialize(),
                beforeSend : function() {

                },
                success : function(result) {
                    if(result == 1)
                    {
                         window.location.href = "style-quiz-bottom"
                    }
                },
                error: function() {

                }
            });
        }
        else
        {
                // console.log('flag = '+flag+' mat = '+mat_flag);
        }
   });


   $('#style_quiz_bottom').on('submit',function(eve){
        eve.preventDefault();

        var mobile_view = $('#mobile_view').val();

        if(mobile_view == 0)
        {
            window.location.href = "style-quiz-shoes-accessories";
        }
        else
        {
            window.location.href = "style-quiz-shoes-accessories-mobile";
        }

        var flag = 0;
        var mat_flag = 0;

        // flag = validate_class('val');
        // console.log(flag); return false;
        // if( $('#special_occation').val() == 'pregnancy' )
        // {
        //     mat_flag = validate_class('mat_val');
        // }

        if(flag == 0 && mat_flag == 0)
        {
            // $.ajax({
            //     type : "POST",
            //     url : host_url + '/style-quiz-bottom',
            //     data: $('#style_quiz_bottom').serialize(),
            //     beforeSend : function() {
            //
            //     },
            //     success : function(result) {
            //         if(result == 1)
            //         {
            //              // window.location.href = "style-quiz-tops-and-dresses"
            //         }
            //     },
            //     error: function() {
            //
            //     }
            // });
        }
        else
        {
                // console.log('flag = '+flag+' mat = '+mat_flag);
        }
   });

   $('#style_quiz_shoes_accessories').on('submit',function(eve){
        eve.preventDefault();

        var mobile_view = $('#mobile_view').val();

        if(mobile_view == 0)
        {
            window.location.href = "style-quiz-budget-pricing";
        }
        else
        {
            window.location.href = "style-quiz-budget-pricing-mobile";
        }

        var flag = 0;
        var mat_flag = 0;

        // flag = validate_class('val');
        // console.log(flag); return false;
        // if( $('#special_occation').val() == 'pregnancy' )
        // {
        //     mat_flag = validate_class('mat_val');
        // }

        if(flag == 0 && mat_flag == 0)
        {
            // $.ajax({
            //     type : "POST",
            //     url : host_url + '/style-quiz-bottom',
            //     data: $('#style_quiz_bottom').serialize(),
            //     beforeSend : function() {
            //
            //     },
            //     success : function(result) {
            //         if(result == 1)
            //         {
            //              // window.location.href = "style-quiz-tops-and-dresses"
            //         }
            //     },
            //     error: function() {
            //
            //     }
            // });
        }
        else
        {
                // console.log('flag = '+flag+' mat = '+mat_flag);
        }
   });

   $('#style_quiz_budget_pricing').on('submit',function(eve){
        eve.preventDefault();

        var mobile_view = $('#mobile_view').val();

        if(mobile_view == 0)
        {
            window.location.href = "schedule";
        }
        else
        {
            window.location.href = "schedule_open";
        }

        var flag = 0;
        var mat_flag = 0;

        // flag = validate_class('val');
        // console.log(flag); return false;
        // if( $('#special_occation').val() == 'pregnancy' )
        // {
        //     mat_flag = validate_class('mat_val');
        // }

        if(flag == 0 && mat_flag == 0)
        {
            // $.ajax({
            //     type : "POST",
            //     url : host_url + '/style-quiz-bottom',
            //     data: $('#style_quiz_bottom').serialize(),
            //     beforeSend : function() {
            //
            //     },
            //     success : function(result) {
            //         if(result == 1)
            //         {
            //              // window.location.href = "style-quiz-tops-and-dresses"
            //         }
            //     },
            //     error: function() {
            //
            //     }
            // });
        }
        else
        {
                // console.log('flag = '+flag+' mat = '+mat_flag);
        }
   });



      function validate_class(cls)
      {
          var flag = 0;
          $('.'+cls).each(function() {

              var input_type = $(this).data('type');

              switch (input_type)
              {
                  case 'select':
                       if($(this).find('option:selected').val() != '' && $(this).find('option:selected').val() != null )
                       {
                           $(this).removeClass('error');
                       }
                       else
                       {
                           console.log($(this).attr('id'));
                           $(this).addClass('error');
                           flag++;
                       }
                   break;

                  case 'text':
                  case 'date':
                       if($(this).val() != '' && $(this).val() != null)
                       {
                           $(this).removeClass('error');
                       }
                       else
                       {
                           console.log($(this).attr('id'));
                           $(this).addClass('error');
                           flag++;
                       }
                   break;

                  case 'number':
                       if($(this).val() != '' && $(this).val() != null && !isNaN($(this).val()))
                       {
                           $(this).removeClass('error');
                       }
                       else
                       {
                           console.log($(this).attr('id'));
                           $(this).addClass('error');
                           flag++;
                       }
                   break;

                   case 'checkbox':
                   case 'radio':

                   var input_name = $(this).attr('name');
                   var error_element = $(this).data('error-ele');
                   if($('input[name="'+ input_name +'"]:checked').length > 0 )
                   {
                       $('.' + error_element).removeClass('error');
                   }
                   else
                   {
                       console.log($(this).attr('id'));
                       $('.' + error_element).addClass('error');
                       flag++;
                   }
              }
          });

          return flag;
      }

      /* Scroll js */
      $.fn.scrollView2 = function (offval) {
        return this.each(function () {
          $('html, body').animate({
            scrollTop: $(this).offset().top - parseInt(offval)
          }, 500);
        });
      }

     /* Sticky steps js */

     // grab the initial top offset of the navigation
     var stickyNavTop = $('.multi-steps').offset().top;

     // our function that decides weather the navigation bar should have "fixed" css position or not.
     var stickyNav = function(){
         var scrollTop = $(window).scrollTop(); // our current vertical position from the top

         // if we've scrolled more than the navigation, change its position to fixed to stick to top,
         // otherwise change it back to relative
         if (scrollTop > stickyNavTop) {
             $('.multi-steps').addClass('multi-step-sticky');
         } else {
             $('.multi-steps').removeClass('multi-step-sticky');
         }
     };

     stickyNav();
     // and run it again every time you scroll
     $(window).scroll(function() {
         stickyNav();
     });

 });
