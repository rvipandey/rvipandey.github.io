$(document).ready(function () {

  $('.top-btn').fadeOut(); // hide scroll to top button when page loads
  var host_url = location.protocol + "//" + location.host + '/';
  //var stylequiz = 'stylequiz';
  //var updatestylequiz = 'updatestylequiz';

  var sqtype = $('#sqtype').attr('ref');
  if(sqtype == 1) {
    var styleRoute = 'updatestylequiz';
  }
  else {
    var styleRoute = 'stylequiz';
  }
  //console.log(styleRoute);

      $('#nxt1').on('click', function () {
        var flag=0;
        var error_div = false;
        $('.validate1').each(function () {
          if ($(this).val() == '' || $(this).val() == null)
          {
             if(error_div==false)
             {
                error_div = this.id;
             }

            $(this).addClass("has-error");
            flag++;
          }
          else
          {
            $(this).removeClass("has-error");
          }
        });
        if($("input[name=height_ft]:checked").length==0)
        {
          $('.radio-picture-height-ft').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-height-ft').removeClass('has-error');
        }

        if($("input[name=height_in]:checked").length==0)
        {
          $('.radio-picture-height-in').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-height-in').removeClass('has-error');
        }

        // if($("input[name=shoe_size]:checked").length==0)
        // {
        //   $('.radio-shoe-size').addClass('has-error');
        //   flag++;
        // }
        // else
        // {
        //   $('.radio-shoe-size').removeClass('has-error');
        // }

        if($("input[name=bra_size]:checked").length==0)
        {
          $('.radio-bra-size').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-bra-size').removeClass('has-error');
        }

        if($("#dob_y").val() == null || $("#dob_y").val() == '')
        {
          $('#dob_y').addClass('has-error');
          flag++;
        }
        else
        {
          $('#dob_y').removeClass('has-error');
        }
        if(flag>0)
        {

          $('#err-1').html('Fields marked in red are compulsory.');
          $('#'+error_div).focus();

          // alert(error_div);
          return false;
        }
        else
        {
          //console.log($('#step1').serialize());return false;
        $.ajax({
                    type : "POST",
                    url : host_url + 'stylequizsave',
                    data : $('#step1').serialize() + "&step=1",
                    beforeSend : function(result) {
                           // $('#err-1').html('Please Wait...');
                    },
                    success : function(result) {

                            if(result == 1)
                            {

                            try {
                                var email = $('#user_email_id').val();
                                var ddate = $('#dob_date').val();
                                var dmonth = $('#dob_month').val();
                                var dyear = $('#dob_year').val();

                                var dob = dmonth+'/'+ddate+'/'+dyear;
                                k = new Date(dob);

                                var dd = k.getDate();
                                var mm = k.getMonth()+1; //January is 0!

                                var yyyy = k.getFullYear();
                                if(dd<10){
                                    dd='0'+dd;
                                }
                                if(mm<10){
                                    mm='0'+mm;
                                }
                                var dob_f = dd+'-'+mm+'-'+yyyy;

                                console.log(dob_f);


                                smartech('contact', '2', {
                                    'pk^email': email,
                                    'DOB': dob_f
                                });
                                smartech('dispatch', 102, {"i^Style_Quiz_Step": "1"});
                                } catch (e) {
                                    console.log(e);
                                } finally {
                                     window.location = host_url + styleRoute + '/step4';  //skipped step 2 and 3
                                    }
                            }
                            else if(result == 0)
                            {
                                    $('#err-1').html('Something went wrong.');
                            }
                        },
                    error: function() {
                        $('#err-1').html('Something went wrong.');
                        }
            });
        }
      });

      $.fn.scrollView = function () {
        return this.each(function () {
          $('html, body').animate({
            scrollTop: $(this).offset().top-100
          }, 500);
        });
      }

      $.fn.scrollView2 = function (offval) {
        return this.each(function () {
          $('html, body').animate({
            scrollTop: $(this).offset().top - parseInt(offval)
          }, 500);
        });
      }

      $('.dob-change1,.dob-change2,.dob-change3').change(function() {
        if($('.dob-change1').val()!==''&$('.dob-change2').val()!==''&$('.dob-change3').val()!=='')
        {
          $('#weight').scrollView2('250');
          $('.dob-change1,.dob-change2,.dob-change3').removeClass('has-error');
        }
      });

      $('.weight-change').change(function() {
        if($(this).val()!=='')
        {
          $('#top_size').scrollView2('250');
          $('.weight-change').removeClass('has-error');
        }
      });

      $('.topsize-change').change(function() {
        if($(this).val()!=='')
        {
          $('#denim_size').scrollView2('250');
          $('.topsize-change').removeClass('has-error');
        }
      });

      $('.denim-size-change').change(function() {
        if($(this).val()!=='')
        {
          $('#blouse_size').scrollView2('250');
           $('.denim-size-change').removeClass('has-error');
        }
      });

      $('.blouse-size-change').change(function() {
        if($(this).val()!=='')
        {
          // $('#height_ft_3').scrollView2('250');
            $('#bust_size').scrollView2('250');
           $('.blouse-size-change').removeClass('has-error');
        }
      });

      $('.radio-picture-height-in').click(function() {
        // $('#shoe_size_35').scrollView2('250');
        $('#bra_size_32a').scrollView2('250');
        $('.radio-picture-height-in').removeClass('has-error');
      });

      $('.bust-size-change').click(function() {
           $('.bust-size-change').removeClass('has-error');
       });

       $('.bust-size-change').on('change',function() {
            $('#height_ft_3').scrollView2('250');
       });


      $('.bust-size-change').on('change',function() {
      	$('#height_ft_3').scrollView2('250');
      });

      $('.radio-picture-height-ft').click(function() {
          $('.radio-picture-height-ft').removeClass('has-error');
      });

      $('.radio-picture-height-ft').on('change',function(){
          $('#height_in_0').scrollView2('250');
      });


      $('.radio-shoe-size').click(function() {
        // $('#bra_size_32a').scrollView2('250');
        $('.radio-shoe-size').removeClass('has-error');
      });

      $('.radio-bra-size').click(function() {
        $('#size_comment').scrollView2('250');
        $('.radio-bra-size').removeClass('has-error');
      });

      $('.radio-picture-type').click(function(){
        $('.radio-picture-type').removeClass('has-error2');
        $('.radio-picture-shape').scrollView2('250');
      });

      //
      // $('.radio-picture-shape').click(function(){
      //   $('.radio-picture-shape').removeClass('has-error2');
      //   $('#student_rd').scrollView2('250');
      // });


      $('#nxt2').on('click', function () {

        var flag = 0;

        if ($("input[name=shoulders]:checked").length == 0)
        {
          $('.radio-picture-shoulders').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-shoulders').removeClass('has-error');
        }

        if ($("input[name=arms]:checked").length == 0)
        {
          $('.radio-picture-arms').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-arms').removeClass('has-error');
        }

        if ($("input[name=torso]:checked").length == 0)
        {
          $('.radio-picture-torso').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-torso').removeClass('has-error');
        }

        if ($("input[name=hips]:checked").length == 0)
        {
          $('.radio-picture-hip').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-hip').removeClass('has-error');
        }

        if ($("input[name=legs]:checked").length == 0)
        {
          $('.radio-picture-legs').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-legs').removeClass('has-error');
        }


        if (flag > 0)
        {
             $('#err-2').html('Fields marked in red are compulsory.');
        }
        else
        {
          $.ajax({
                    type : "POST",
                    url : host_url + 'stylequizsave',
                    data : $('#step2').serialize() + "&step=2",
                    beforeSend : function(result) {
                            //$('#err-2').html('Please Wait...');
                    },
                    success : function(result) {
                            // $('#nxt2').html('Continue');
                            if(result == 1)
                            {
                                window.location = host_url + styleRoute + '/step3';
                            }
                            else if(result == 0)
                            {
                                    $('#err-2').html('Something went wrong.');
                            }
                        },
                    error: function() {
                            $('#err-2').html('Something went wrong.');
                        }
            });
        }
      });
      $('#prv2').on('click', function () {
        window.location = host_url + styleRoute + '/step1';
      });

      $('.radio-picture-shoulders').click(function(){
       $('#arms_short').scrollView2('250');
       $('.radio-picture-shoulders').removeClass('has-error');
      });

      $('.radio-picture-arms').click(function(){
       $('#torso_short').scrollView2('250');
       $('.radio-picture-arms').removeClass('has-error');
      });

      $('.radio-picture-torso').click(function(){
       $('#hips_narrow').scrollView2('250');
       $('.radio-picture-torso').removeClass('has-error');
      });

      $('.radio-picture-hip').click(function(){
        $('#legs_short').scrollView2('250');
        $('.radio-picture-hip').removeClass('has-error');
      });

      $('.radio-picture-legs').click(function(){
          $('#nxt2').scrollView2('250');
        $('.radio-picture-legs').removeClass('has-error');
      });



      $('#nxt3').on('click', function () {

        var flag=0;

        if($("input[name=skin_tone]:checked").length==0)
        {
          $('.radio-picture-tone').addClass('has-error2');
          flag++;
        }
        else
        {
          $('.radio-picture-tone').removeClass('has-error2');
        }
        if(flag>0)
        {
            $('#err-3').html('Field marked in red is compulsory.');
        }
        else
        {
         $.ajax({
                    type : "POST",
                    url : host_url + 'stylequizsave',
                    data : $('#step3').serialize() + "&step=3",
                    beforeSend : function(result) {
                            //$('#err-3').html('Please Wait...');
                    },
                    success : function(result) {
                            // $('#nxt3').html('Continue');
                            if(result == 1)
                            {
                                window.location = host_url + styleRoute + '/step4';
                            }
                            else if(result == 0)
                            {
                                    $('#err-3').html('Something went wrong.');
                            }
                        },
                    error: function() {
                            $('#err-3').html('Something went wrong.');
                        }
            });
        }
      });
      $('#prv3').on('click', function () {
        window.location = host_url + styleRoute + '/step2';
      });

      $('.radio-picture-tone').click(function(){
        $('.radio-picture-tone').removeClass('has-error2');
        $('#nxt3').scrollView2('250');
      });


      $('#nxt4').on('click', function () {
       var flag=0;

       if($("input[name=body_shape]:checked").length==0)
       {
           $('.radio-picture-shape').addClass('has-error2');
           flag++;
        }
        else
        {
            $('.radio-picture-shape').removeClass('has-error2');
        }

        if($("input[name=body_type]:checked").length==0)
        {
           $('.radio-picture-type').addClass('has-error2');
           flag++;
        }
        else
        {
            $('.radio-picture-type').removeClass('has-error2');
        }

        if($("input[name=profession_new]:checked").length==0)
        {
         $('.radio-picture-profession').addClass('has-error2');
         flag++;
        }
        else
        {
         $('.radio-picture-profession').removeClass('has-error2');
         if($("input[name=profession_new]:checked").attr('id')=='others_rd')
         {
           if($.trim($('#other_text').val())=='' || $('#other_text').val() == null)
           {
               // alert('asdasdas');
               $('#other_text').addClass('has-error2');
               flag ++;
           }
           else
           {
             $('#other_text').removeClass('has-error2');
           }
         }

       }


        if(flag>0)
        {
          $('#err-4').html('Field marked in red is compulsory.');
        }
        else
        {
        $.ajax({
                    type : "POST",
                    url : host_url + 'stylequizsave',
                    data : $('#step4').serialize() + "&step=4",
                    beforeSend : function(result) {
                            //$('#err-4').html('Please Wait...');
                    },
                    success : function(result) {
                            // $('#nxt4').html('Continue');
                            if(result == 1)
                            {
                                try {

                                    smartech('dispatch', 103, {"i^Style_Quiz_Step": "4"});
                                    } catch (e) {
                                        console.log(e);
                                    } finally {
                                        window.location = host_url + styleRoute + '/step5'; //Nirmeet added new step
                                    }

                            }
                            else if(result == 0)
                            {
                                    $('#err-4').html('Something went wrong.');
                            }
                        },
                    error: function() {
                            $('#err-4').html('Something went wrong.');
                        }
            });
      }
      });
      $('#prv4').on('click', function () {
        window.location = host_url + styleRoute + '/step1';
      });


      $('.radio-picture-shape').click(function(){
        $('.radio-picture-shape').removeClass('has-error2');
        $('#student').scrollView2('250');
      });

      $('.radio-picture-profession').click(function(){
        $('.radio-picture-profession').removeClass('has-error2');
        $('#nxt4').scrollView2('250');
      });

      $('#nxt5').on('click', function () {
        var flag=0;

      //            alert($(".topfit-validate:checked").length);
      if($(".topfit-validate:checked").length==0)
      {
        $('.radio-picture-topfit').addClass('has-error');
        flag++;
      }
      else
      {
        $('.radio-picture-topfit').removeClass('has-error');
      }

      if($(".bottomfit-validate:checked").length==0)
      {
        $('.radio-picture-bottomfit').addClass('has-error');
        flag++;
      }
      else
      {
        $('.radio-picture-bottomfit').removeClass('has-error');
      }

      // if($(".bottomfit-validate:checked").length==0)
      // {
      //   $('.radio-picture-bottomfit').addClass('has-error');
      //   flag++;
      // }
      // else
      // {
      //   $('.radio-picture-bottomfit').removeClass('has-error');
      // }

      if($(".skirtfit-validate:checked").length==0)
      {
        $('.radio-picture-skirtfit').addClass('has-error');
        flag++;
      }
      else
      {
        $('.radio-picture-skirtfit').removeClass('has-error');
      }
      if(flag>0)
      {
          $('#err-5').html('Fields marked in red are compulsory.');
      }
      else
      {
            $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step5').serialize() + "&step=5",
                        beforeSend : function(result) {
                                //$('#err-5').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#err-5').html('Continue');
                                if(result == 1)
                                {
                                    try {
                                        smartech('dispatch', 105, {"i^Style_Quiz_Step": "5"});
                                    } catch (e) {
                                        console.log(e);
                                    } finally {

                                        window.location = host_url + styleRoute + '/step6';
                                    }

                                }
                                else if(result == 0)
                                {
                                        $('#err-5').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-5').html('Something went wrong.');
                            }
                });
      }
      });

       /* nirmeet add new step start */
      $('#nxt4_1').on('click', function () {
      var flag=0;

      if(flag>0)
      {
          $('#err-4_1').html('Field marked in red is compulsory.');
      }
      else
      {
        $.ajax({
                    type : "POST",
                    url : host_url + 'stylequizsave',
                    data : $('#step4_1').serialize() + "&step=41",
                    beforeSend : function(result) {
                            //$('#err-4').html('Please Wait...');
                    },
                    success : function(result) {
                            // $('#nxt4').html('Continue');
                            if(result == 1)
                            {
                                try {
                                        smartech('dispatch', 104, {"i^Style_Quiz_Step": "4.1"});
                                    } catch (e) {
                                        // console.log(e);
                                    } finally {

                                        window.location = host_url + styleRoute + '/step5';   //nirmeet added new step
                                        }

                            }
                            else if(result == 0)
                            {
                                    $('#err-4_1').html('Something went wrong.');
                            }
                        },
                    error: function() {
                            $('#err-4_1').html('Something went wrong.');
                        }
            });
      }
      });
      $('#prv4_1').on('click', function () {
        window.location = host_url + styleRoute + '/step4';
      });

      $(" #student, #homemaker, #fashion_ind, #retail, #advertising ,#finance ,#marketing ,#medicine ,#law , #actor_sin_mod ").click(function() {
       $('#prv4_1').scrollView2('250');
        $('.radio-picture-profession').removeClass('has-error');
      });

      /* nirmeet add new step end */

      $('#prv5').on('click', function () {
        window.location = host_url + styleRoute + '/step4_1';
      });


      $('.radio-picture-topfit').click(function(){
        $('.radio-picture-topfit').removeClass('has-error');
      });

      $('.radio-picture-bottomfit').click(function(){
        $('.radio-picture-bottomfit').removeClass('has-error');
      });

      $('.radio-picture-skirtfit').click(function(){
        $('.radio-picture-skirtfit').removeClass('has-error');
      });

      $('#spend_tops').on('change',function(){
          $('#spend_denims').scrollView2('250');
      });

      $('#spend_denims').on('change',function(){
          $('#spend_skirt').scrollView2('250');
      });

      $('#spend_skirt').on('change',function(){
          $('#spend_jacket').scrollView2('250');
      });

      $('#spend_jacket').on('change',function(){
          $('#spend_abaya').scrollView2('250');
      });

      $('#spend_abaya').on('change',function(){
          $('#abaya_wearing_time').scrollView2('250');
      });

      $('#abaya_wearing_time').on('change',function(){
          $('#abaya').scrollView2('250');
      });


      $('#nxt6').on('click', function () {

        var flag=0;

        if($('.preferWear1:checked').length<1)
        {
          $('.pw1').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw1').removeClass('has-error');
        }

        if($('.preferWear2:checked').length<1)
        {
          $('.pw2').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw2').removeClass('has-error');
        }

        if($('.preferWear3:checked').length<1)
        {
          $('.pw3').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw3').removeClass('has-error');
        }

        if($('.preferWear5:checked').length<1)
        {
          $('.pw5').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw5').removeClass('has-error');
        }

        if($('.preferWear6:checked').length<1)
        {
          $('.pw6').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw6').removeClass('has-error');
        }

        if($('.preferWear7:checked').length<1)
        {
          $('.pw7').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw7').removeClass('has-error');
        }

        if($('.preferWear8:checked').length<1)
        {
          $('.pw8').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw8').removeClass('has-error');
        }

        if($('.preferWear9:checked').length<1)
        {
          $('.pw9').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw9').removeClass('has-error');
        }


        if($('.preferWear12:checked').length<1)
        {
          $('.pw12').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw12').removeClass('has-error');
        }

        if($('.preferWear13:checked').length<1)
        {
          $('.pw13').addClass('has-error');
          flag++;
        }
        else
        {
          $('.pw13').removeClass('has-error');
        }


        if($(".bot-len-validate:checked").length==0)
        {
          $('.radio-picture-bottomlen').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-bottomlen').removeClass('has-error');
        }

        if($(".shot-pant-validate:checked").length==0)
        {
          $('.radio-picture-shortlen').addClass('has-error');
          flag++;
        }
        else
        {
          $('.radio-picture-shortlen').removeClass('has-error');
        }



        $('.radio-picture-bottomlen').click(function(){
          $('.radio-picture-bottomlen').removeClass('has-error');
        });

        if(flag>0)
        {
             $('#err-6').html('Fields marked in red are compulsory.');
        }
        else
        {
                $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step6').serialize() + "&step=6",
                        beforeSend : function(result) {
                                //$('#err-6').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#err-6').html('Continue');
                                if(result == 1)
                                {
                                    try {
                                        smartech('dispatch', 106, {"i^Style_Quiz_Step": "6"});
                                    } catch (e) {
                                        console.log(e);
                                    } finally {
                                        window.location = host_url + styleRoute + '/step8';   //skipped step 7
                                    }

                                }
                                else if(result == 0)
                                {
                                        $('#err-6').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-6').html('Something went wrong.');
                            }
                });
        }


      });

      // $.fn.scrollView2 = function (offval) {
      //   return this.each(function () {
      //     $('html, body').animate({
      //       scrollTop: $(this).offset().top - parseInt(offval)
      //     }, 1000);
      //   });
      // }

      $( "#sleeveless_yes,#sleeveless_no" ).click(function() {
          $('.pw2').scrollView2('150');
          $('.pw1').removeClass('has-error');
      });

      $( "#backless_yes,#backless_no" ).click(function() {
          $('.pw12').scrollView2('150');
          $('.pw2').removeClass('has-error');
      });

      $( "#offshoulder_yes,#offshoulder_no").click(function() {
          $('.pw12').scrollView2('150');
          $('.pw6').removeClass('has-error');
      });

      $( "#coldshoulder_yes,#coldshoulder_no").click(function() {
          $('.pw13').scrollView2('150');
          $('.pw6').removeClass('has-error');
      });
      $( "#oneshoulder_yes,#oneshoulder_no").click(function() {
          $('.pw5').scrollView2('150');
          $('.pw6').removeClass('has-error');
      });

    $( "#halter_yes,#halter_no").click(function() {
         $('.pw3').scrollView2('150');
          $('.pw5').removeClass('has-error');
        });

      $( "#crop_yes,#crop_no" ).click(function() {
       $('.pw7').scrollView2('150');
        $('.pw3').removeClass('has-error');
      });

        $( "#cut_yes,#cut_no").click(function() {
         $('.pw8').scrollView2('150');
          $('.pw7').removeClass('has-error');
        });


      $( "#deep_yes,#deep_no").click(function() {
       $('.pw9').scrollView2('150');
        $('.pw8').removeClass('has-error');
      });


      $( "#tube_yes,#tube_no").click(function() {
       $('#very_short').scrollView2('150');
        $('.pw9').removeClass('has-error');
      });

     $('#prv6').on('click', function () {
        window.location = host_url + styleRoute + '/step5';
      });

      $('#nxt7').on('click', function () {
        var flag= 0;
        if($('.lookbk1:checked').length==0)
        {
          $('.lookbook-pic').addClass('has-error');
          flag++;
        }
        else
        {
          $('.lookbook-pic').removeClass('has-error');
        }
        if(flag>0)
        {
              $('#err-7').html('Field marked in red is compulsory.');
        }
        else
        {
              $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step7').serialize() + "&step=7",
                        beforeSend : function(result) {
                                //$('#err-7').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#nxt7').html('Continue');
                                if(result == 1)
                                {
                                    window.location = host_url + styleRoute + '/step8';
                                }
                                else if(result == 0)
                                {
                                        $('#err-7').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-7').html('Something went wrong.');
                            }
                });
        }

      });
      $('#prv7').on('click', function () {
        window.location = host_url + styleRoute + '/step6';
      });

       $('.lookbook-pic').click(function(){
          $('.lookbook-pic').removeClass('has-error');
       });

       $( "#spend_accessories").click(function() {
        $('#statement').scrollView2('150');
       });

       $( "#spend_bags").click(function() {
        $('#hand_b').scrollView2('150');
       });

      $('#nxt8').on('click', function () {
        var flag=0;


        if($(".clothing-brand-validate:checked").length==0)
        {
          $('.check-picture-clothingbrand').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-picture-clothingbrand').removeClass('has-error');
        }

        $('.validate8').each(function () {
          if ($(this).val() == '' || $(this).val() == null)
          {
            $(this).addClass("has-error");
            flag++;
          }
          else
          {
            $(this).removeClass("has-error");
          }
        });


        if(flag>0)
        {
             $('#err-8').html('Fields marked in red are compulsory.');
        }
        else
        {
                 $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step8').serialize() + "&step=8",
                        beforeSend : function(result) {
                               // $('#err-8').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#nxt8').html('Continue');
                                if(result == 1)
                                {
                                    try {
                                        smartech('dispatch', 107, {"i^Style_Quiz_Step": "8"});
                                    } catch (e) {
                                        console.log(e);
                                    } finally {

                                        window.location = host_url + styleRoute + '/step9';
                                    }

                                }
                                else if(result == 0)
                                {
                                    $('#err-8').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-8').html('Something went wrong.');
                            }
                });
        }
      });

      $('#prv8').on('click', function () {
        window.location = host_url + styleRoute + '/step6   '; //skipped step 7
      });

      $('.check-picture-jewel').click(function(){
        $('.check-picture-jewel').removeClass('has-error');
      });


      $('.check-picture-jeweltone').click(function(){
        $('.check-picture-jeweltone').removeClass('has-error');
      });


      $('.check-picture-bag').click(function(){
        $('.check-picture-bag').removeClass('has-error');
      });


      $('#nxt9').on('click', function () {

        var flag = 0;

        if(!$(".accessories-brand-validate").is(":checked"))
        {
          $('.check-picture-accessoriesbrand').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-picture-accessoriesbrand').removeClass('has-error');
        }

        if(!$(".jew-style-validate").is(":checked"))
        {
          $('.check-picture-jewel').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-picture-jewel').removeClass('has-error');
        }

        if(!$(".pref-wear-validate").is(":checked"))
        {
          $('.check-pref-wear').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-pref-wear').removeClass('has-error');
        }

        if(!$(".belt-pref-validate").is(":checked"))
        {
          $('.check-belt-pref').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-belt-pref').removeClass('has-error');
        }

        $('.validate9').each(function () {
          if ($(this).val() == '' || $(this).val() == null)
          {
            $(this).addClass("has-error");
            flag++;
          }
          else
          {
            $(this).removeClass("has-error");
          }
        });


        if(flag>0)
        {
             $('#err-8').html('Fields marked in red are compulsory.');
        }
        else
        {
                $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step9').serialize() + "&step=9",
                        beforeSend : function(result) {
                                //$('#err-9').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#nxt9').html('Continue');
                                if(result == 1)
                                {
                                    try {
                                        smartech('dispatch', 108, {"i^Style_Quiz_Step": "9"});
                                    } catch (e) {
                                        console.log(e);
                                    } finally {
                                        window.location = host_url + styleRoute + '/step10';  //skipped step 10

                                    }

                                }
                                else if(result == 0)
                                {
                                        $('#err-9').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-9').html('Something went wrong.');
                            }
                });
              }
      });
      $('#prv9').on('click', function () {
        window.location = host_url + styleRoute + '/step8';
      });
       $('#nxt10').on('click', function () {
        var flag=0;
        if(!$(".bags-brand-validate").is(":checked"))
        {
          $('.check-picture-bagsbrand').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-picture-bagsbrand').removeClass('has-error');
        }

        if(!$(".bag-style-validate").is(":checked"))
        {
          $('.check-picture-bag').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-picture-bag').removeClass('has-error');
        }

        if(!$(".bag-color-validate").is(":checked"))
        {
          $('.check-color-bag').addClass('has-error');
          flag++;
        }
        else
        {
          $('.check-color-bag').removeClass('has-error');
        }

        $('.validate10').each(function () {
          if ($(this).val() == '' || $(this).val() == null)
          {
            $(this).addClass("has-error");
            flag++;
          }
          else
          {
            $(this).removeClass("has-error");
          }
        });

      //   if($(".topspent-validate:checked").length==0)
      //   {
      //     $('.radio-picture-topspent').addClass('has-error');
      //     flag++;
      //   }
      //   else
      //   {
      //     $('.radio-picture-topspent').removeClass('has-error');
      //   }
      //
      //   if($(".bottomspent-validate:checked").length==0)
      //   {
      //     $('.radio-picture-bottomspent').addClass('has-error');
      //     flag++;
      //   }
      //   else
      //   {
      //     $('.radio-picture-bottomspent').removeClass('has-error');
      //   }
      //
      //   if($(".dressesspent-validate:checked").length==0)
      //   {
      //     $('.radio-picture-dressesspent').addClass('has-error');
      //     flag++;
      //   }
      //   else
      //   {
      //     $('.radio-picture-dressesspent').removeClass('has-error');
      //   }
      //
      //
      //   if($(".bagspent-validate:checked").length==0)
      //   {
      //     $('.radio-picture-bagspent').addClass('has-error');
      //     flag++;
      //   }
      //   else
      //   {
      //     $('.radio-picture-bagspent').removeClass('has-error');
      //   }
      //
      // if($(".jewelspent-validate:checked").length==0)
      //   {
      //     $('.radio-picture-jewelspent').addClass('has-error');
      //     flag++;
      //   }
      //   else
      //   {
      //     $('.radio-picture-jewelspent').removeClass('has-error');
      //   }
      //
      //
      // if($(".accspent-validate:checked").length==0)
      //   {
      //     $('.radio-picture-accspent').addClass('has-error');
      //     flag++;
      //   }
      //   else
      //   {
      //     $('.radio-picture-accspent').removeClass('has-error');
      //   }


         if(flag>0)
        {
              $('#err-10').html('Field marked in red is compulsory.');
        }
        else
        {
          $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step10').serialize() + "&step=10",
                        beforeSend : function(result) {
                               // $('#err-10').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#err-10').html('Continue');
                                if(result == 1)
                                {
                                    window.location = host_url + styleRoute + '/step11';
                                }
                                else if(result == 0)
                                {
                                        $('#err-10').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-10').html('Something went wrong.');
                            }
                });
        }
        });
        $('#prv10').on('click', function () {
            window.location = host_url + styleRoute + '/step9';
        });

       $('#nxt11').on('click', function () {
                   $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step11').serialize() + "&step=11",
                        beforeSend : function(result) {
                                //$('#err-11').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#nxt11').html('Continue');
                                if(result == 1)
                                {
                                    try {

                                    } catch (e) {
                                        console.log(e);
                                        } finally {
                                        window.location = host_url + styleRoute + '/step12';
                                    }
                                }
                                else if(result == 0)
                                {
                                        $('#err-11').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-11').html('Something went wrong.');
                            }
                });
        });

        $('#prv11').on('click', function () {
            window.location = host_url + styleRoute + '/step10';
        });

       $('#nxt12').on('click', function () {
                   $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step12').serialize() + "&step=12",
                        beforeSend : function(result) {
                                //$('#err-11').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#nxt11').html('Continue');
                                if(result == 1)
                                {
                                    try {

                                    } catch (e) {
                                        console.log(e);
                                        } finally {
                                        window.location = host_url + styleRoute + '/step13';
                                    }
                                }
                                else if(result == 0)
                                {
                                        $('#err-12').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-12').html('Something went wrong.');
                            }
                });
        });

        $('#prv13').on('click', function () {
            window.location = host_url + styleRoute + '/step12';  //skipped 10
        });

       $('#nxt13').on('click', function () {
                   $.ajax({
                        type : "POST",
                        url : host_url + 'stylequizsave',
                        data : $('#step13').serialize() + "&step=13",
                        beforeSend : function(result) {
                                //$('#err-11').html('Please Wait...');
                        },
                        success : function(result) {
                                // $('#nxt11').html('Continue');
                                if(result == 1)
                                {
                                    try {

                                    } catch (e) {
                                        console.log(e);
                                        } finally {
                                        window.location = host_url + '/schedule';
                                    }
                                }
                                else if(result == 0)
                                {
                                        $('#err-13').html('Something went wrong.');
                                }
                            },
                        error: function() {
                                $('#err-13').html('Something went wrong.');
                            }
                });
        });

        $('#prv11').on('click', function () {
            window.location = host_url + styleRoute + '/step11';  //skipped 10
        });

        var bar = $('.bar');
  var percent = $('.percent');
  var status = $('#status');

//        $('form').ajaxForm({
//      beforeSend: function() {
//                alert('dfsdfsd');
//        status.empty();
//        body = '';
//                $("#next12").val('Please wait...............');
////        $("#check-data").attr("disabled", true);
////        $("#behaviour").attr("disabled", true);
//        //timer = setTimeout('getProgress()',5000);
//                //alert(timer);
//      },
//      success: function() {
////        $("#bulk").empty();
////        clearTimeout(timer);
//      },
//    complete: function(xhr) {
//      //status.html(xhr.responseText);
//      //status.empty();
//      clearTimeout(timer);
//      var res = $.parseJSON(xhr.responseText);
//      if(res.error) {
//        status.append("Please rectify the below mentioned errors.<br /></br />");
//        //for(var i in res.error) {
//        scan(res.error);
//                                //console.log(body);
//        status.append( body +"<br />");
//        //}
//        $("#nxt12").val('Check Data');
////        $("#check-data").attr("disabled", false);
////        $("#behaviour").attr("disabled", false);
//        hit=0;
//      }
//      else if(res.success){
//        for(var i in res.success) {
//          status.append(res.success[i]);
//        }
//        hit=1;
//        $("#nxt12").hide();
////        $("#save-data").show();
//      }
//      else {
//        alert("ZOIKS");
//      }
//    },
//    error:function(t) {
//      console.log(t);
//    }
//  });


//         $('#nxt12').on('click', function () {
//
//             var sqimg = $('#file-2').val();
////             alert(sqimg);return false;
//
//             ajax_data = {
//        sqimg: sqimg
//      }
//
//             $.ajax({
//                        type : "POST",
//                        url : host_url + 'uploadImg',
//                        data : ajax_data,
//                        cache: false,
//                        dataType: 'json',
//                        processData: false, // Don't process the files
//                        contentType: false, // Set content type to false as jQuery will tell the server its a query string request
//                        beforeSend : function(result) {
//                                $('#nxt12').html('Please Wait...');
//                        },
//                        success : function(result) {
//                                $('#nxt11').html('Continue');
//                                if(result == 1)
//                                {
//                                   alert('Success');
//                                }
//                                else if(result == 0)
//                                {
//                                            alert('Fail');
//                                }
//                            },
//                        error: function() {
//                                        alert('Fail');
//                            }
//                });
//        });
           $('#prv12').on('click', function () {
            window.location = host_url + 'stylequiz/step11';
        });


           $('.radio-picture-topspent').click(function(){
            $('.radio-picture-topspent').removeClass('has-error');
            $('#bottom_spent_1').scrollView2('300');
        });

        $('.radio-picture-bottomspent').click(function(){
            $('.radio-picture-bottomspent').removeClass('has-error');
            $('#dresses_spent_1').scrollView2('300');
        });

        $('.radio-picture-dressesspent').click(function(){
            $('.radio-picture-dressesspent').removeClass('has-error');
            $('#bags_spent_1').scrollView2('300');
        });

        $('.radio-picture-bagspent').click(function(){
            $('.radio-picture-bagspent').removeClass('has-error');
            $('#jewelspent_1').scrollView2('300');
        });

        $('.radio-picture-jewelspent').click(function(){
            $('.radio-picture-jewelspent').removeClass('has-error');
            $('#accspent_1').scrollView2('300');
        });

        $('.radio-picture-accspent').click(function(){
          $('.radio-picture-accspent').removeClass('has-error');
            $('#nxt10').scrollView2('250');
        });

        // $('.radio-picture-topspent').click(function(){
        //     $('#bottom_spent_1').scrollView2('300');
        // });


        $('.top-btn').click(function(){
          window.scrollTo(0,0);
        });

      });

$(window).scroll(function() {
    if ($(this).scrollTop()) {
        $('.top-btn').fadeIn();
    } else {
        $('.top-btn').fadeOut();
    }
});


      /*
  By Osvaldas Valutis, www.osvaldas.info
  Available for use under the MIT License
*/

//'use strict';
//
//;( function( $, window, document, undefined )
//{
//  $( '.inputfile' ).each( function()
//  {
//    var $input   = $( this ),
//      $label   = $input.next( 'label' ),
//      labelVal = $label.html();
//
//    $input.on( 'change', function( e )
//    {
//      var fileName = '';
//
//      if( this.files && this.files.length > 1 )
//        fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
//      else if( e.target.value )
//        fileName = e.target.value.split( '\\' ).pop();
//
//      if( fileName )
//        $label.find( 'span' ).html( fileName );
//      else
//        $label.html( labelVal );
//    });
//
//    // Firefox bug fix
//    $input
//    .on( 'focus', function(){ $input.addClass( 'has-focus' ); })
//    .on( 'blur', function(){ $input.removeClass( 'has-focus' ); });
//  });
//})( jQuery, window, document );
//
///*
//  By Osvaldas Valutis, www.osvaldas.info
//  Available for use under the MIT License
//*/
//
//'use strict';
//
//;( function ( document, window, index )
//{
//  var inputs = document.querySelectorAll( '.inputfile' );
//  Array.prototype.forEach.call( inputs, function( input )
//  {
//    var label  = input.nextElementSibling,
//      labelVal = label.innerHTML;
//
//    input.addEventListener( 'change', function( e )
//    {
//      var fileName = '';
//      if( this.files && this.files.length > 1 )
//        fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
//      else
//        fileName = e.target.value.split( '\\' ).pop();
//
//      if( fileName )
//        label.querySelector( 'span' ).innerHTML = fileName;
//      else
//        label.innerHTML = labelVal;
//    });
//
//    // Firefox bug fix
//    input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
//    input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
//  });
//}( document, window, 0 ));
