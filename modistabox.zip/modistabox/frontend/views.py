import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import *
from django.contrib import  admin
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.files.storage import FileSystemStorage
from django.contrib import auth
from frontend.models import UserData,about_yourself as ay,first_page as fp
from twilio.rest import Client
#from login_views import opt_generate
#from frontend.models import userlogin
# Create your views here.



def custom_decorator(f):
    def wrap(request,*args,**kwargs):
        if 'sessionid' not in request.session.keys():
            return HttpResponseRedirect('/Index/')
        return f(request,*args,**kwargs)
    wrap.__doc__=f.__doc__
    wrap.__name__=f.__name__
    return wrap



def tex(request):
    return render(request,'sex.html')

# def test(request):
#     article = UserData()
#     article.user_mobile = '9759076337'
#     article.user_country = 'DUBAI'
#     article.save()

# #user=auth.authenticate(usrname='sss',pwd='ssssss')
# def first_page_insert(request):
#     if(request.method=="POST"):
#         fpage=fp()
#         fpage.styleid="1"
#         fpage.looking_style=request.POST.get('looking_style')
#         print(request.POST.get('looking_style'))
#         fpage.birthday=request.POST.get('birthday')
#         fpage.occasion=request.POST.get('occasion')
#         fpage.session=str(request.session['sessionid'])
#         fpage.last_session_time="-----"
#         fpage.save()
#         return render(request,'about_yourself.html')

@custom_decorator
def about_yourself_insert(request):
    if(request.method=='POST'):
        abt=ay()
        abt.session=str(request.session['sessionid'])
        abt.skin_tone=request.POST.get('skin_color')
        abt.styleid='1'
        abt.save()
        return HttpResponseRedirect('/tops_dresses/')
    return render(request,'index.html')
    

def login(request):
    if(request.method=='POST'):
        user_mobile=request.POST.get('user_mobile')
        user_country=request.POST.get('user_country')
        print(user_mobile)
        print(user_country)
        exist= UserData.objects.filter(user_mobile=user_mobile).count()
        #opt_generate(user_country,user_mobile)
        if(exist>=1):
            request.session['sessionid']=str(user_mobile)
            return HttpResponseRedirect('/first_page/')
        return render(request,'index.html')


def myView(request, param):  
  if not param:  
    return HttpResponseNotFound('<h1>No Page Here</h1>') 

def custom_404(request):
    return render_to_response('index.html')

def modistafront(request):
    return render(request,'index.html')

def faq(request):
    return render(request,'faq.html')
    
def about(request):
    #test()
    return render(request,'about.html')    

def giftcard(request):
    return render(request,'giftcard.html')

def career(request):
    return render(request,'career.html')
@custom_decorator
def first_page(request):
    if(request.method=="POST"):
        fpage=fp()
        fpage.styleid="1"
        fpage.looking_style=request.POST.get('looking_style')
        print(request.POST.get('looking_style'))
        fpage.birthday=request.POST.get('birthday')
        fpage.occasion=request.POST.get('occasion')
        fpage.session=str(request.session['sessionid'])
        fpage.last_session_time="-----"
        fpage.save()
        return HttpResponseRedirect('/about_yourself/')

    
    return render(request,'quiz/first_page.html')
@custom_decorator
def about_yourself(request):
    return render(request,'quiz/about_yourself.html')
@custom_decorator
def tops_dresses(request):
    return render(request,'quiz/tops_dresses.html')
@custom_decorator
def bottom(request):
    return render(request,'quiz/bottom.html')
@custom_decorator
def shoe_accessories(request):
    return render(request,'quiz/shoe_accessories.html')
@custom_decorator
def budget_pricing(request):
    return render(request,'quiz/budget_pricing.html')  




# def login_user(request):
#     #logout(request)
#     username = country = ''
#     if request.POST:
#         username = request.POST['user_mobile']
#         password = request.POST['country']
#         user = '97590763333'
#         if user is not None:
#             if user.is_active:
#                 #login(request, user)
#                 return HttpResponseRedirect('/first_page/')
#     return render_to_response('/first_page/', context_instance=RequestContext(request))

